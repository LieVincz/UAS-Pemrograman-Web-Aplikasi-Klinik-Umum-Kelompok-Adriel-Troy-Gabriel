package com.klinikumum.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.klinikumum.R;
import com.klinikumum.models.*;
import com.klinikumum.network.ApiClient;
import com.klinikumum.utils.SessionManager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminMainActivity extends AppCompatActivity {

    private SessionManager session;
    private TextView tvPasienHariIni, tvMenunggu;
    private SwipeRefreshLayout swipeRefresh;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_main);

        session = new SessionManager(this);

        tvPasienHariIni = findViewById(R.id.tvPasienHariIni);
        tvMenunggu      = findViewById(R.id.tvMenunggu);
        swipeRefresh    = findViewById(R.id.swipeRefresh);
        progressBar     = findViewById(R.id.progressBar);

        swipeRefresh.setOnRefreshListener(() -> {
            loadDashboard();
            swipeRefresh.setRefreshing(false);
        });

        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setSelectedItemId(R.id.nav_home);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_antrian) {
                startActivity(new Intent(this, AdminPendaftaranActivity.class));
            } else if (id == R.id.nav_profil) {
                startActivity(new Intent(this, ProfilActivity.class));
            }
            return true;
        });

        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            session.logout();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        loadDashboard();
    }

    @Override protected void onResume() { super.onResume(); loadDashboard(); }

    private void loadDashboard() {
        progressBar.setVisibility(View.VISIBLE);
        String token = "Bearer " + session.getToken();

        ApiClient.getService().getDashboard(token).enqueue(new Callback<BaseResponse<DashboardData>>() {
            @Override
            public void onResponse(Call<BaseResponse<DashboardData>> call, Response<BaseResponse<DashboardData>> response) {
                progressBar.setVisibility(View.GONE);
                if (response.isSuccessful() && response.body() != null && response.body().status) {
                    DashboardData data = response.body().data;
                    tvPasienHariIni.setText(String.valueOf(data.pasienHariIni));
                    tvMenunggu.setText(String.valueOf(data.antrianMenunggu));
                }
            }
            @Override
            public void onFailure(Call<BaseResponse<DashboardData>> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(AdminMainActivity.this, "Gagal memuat: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
