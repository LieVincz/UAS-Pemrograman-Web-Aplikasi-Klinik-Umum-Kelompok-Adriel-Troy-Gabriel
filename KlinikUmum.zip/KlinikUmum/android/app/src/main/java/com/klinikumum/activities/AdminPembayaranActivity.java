package com.klinikumum.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.klinikumum.R;
import com.klinikumum.adapters.PembayaranAdapter;
import com.klinikumum.models.*;
import com.klinikumum.network.ApiClient;
import com.klinikumum.utils.SessionManager;
import java.util.*;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminPembayaranActivity extends AppCompatActivity {

    private SessionManager session;
    private RecyclerView rvPembayaran;
    private ProgressBar progressBar;
    private PembayaranAdapter adapter;
    private List<Pembayaran> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pembayaran_list);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Manajemen Pembayaran");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> finish());

        session = new SessionManager(this);
        rvPembayaran = findViewById(R.id.rvPembayaran);
        progressBar  = findViewById(R.id.progressBar);

        adapter = new PembayaranAdapter(list, this::konfirmasiBayar);
        rvPembayaran.setLayoutManager(new LinearLayoutManager(this));
        rvPembayaran.setAdapter(adapter);

        loadData();
    }

    private void loadData() {
        progressBar.setVisibility(View.VISIBLE);
        String token = "Bearer " + session.getToken();
        ApiClient.getService().getListPembayaran(token).enqueue(new Callback<BaseResponse<List<Pembayaran>>>() {
            @Override
            public void onResponse(Call<BaseResponse<List<Pembayaran>>> call, Response<BaseResponse<List<Pembayaran>>> response) {
                progressBar.setVisibility(View.GONE);
                if (response.isSuccessful() && response.body() != null && response.body().status) {
                    list.clear();
                    list.addAll(response.body().data);
                    adapter.notifyDataSetChanged();
                }
            }
            @Override
            public void onFailure(Call<BaseResponse<List<Pembayaran>>> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
            }
        });
    }

    private void konfirmasiBayar(Pembayaran p) {
        String token = "Bearer " + session.getToken();
        Map<String, Object> body = new HashMap<>();
        body.put("id", p.id);
        ApiClient.getService().konfirmasiPembayaran(token, body).enqueue(new Callback<BaseResponse<Object>>() {
            @Override
            public void onResponse(Call<BaseResponse<Object>> call, Response<BaseResponse<Object>> response) {
                Toast.makeText(AdminPembayaranActivity.this, "Pembayaran dikonfirmasi!", Toast.LENGTH_SHORT).show();
                loadData();
            }
            @Override public void onFailure(Call<BaseResponse<Object>> call, Throwable t) {}
        });
    }
}
