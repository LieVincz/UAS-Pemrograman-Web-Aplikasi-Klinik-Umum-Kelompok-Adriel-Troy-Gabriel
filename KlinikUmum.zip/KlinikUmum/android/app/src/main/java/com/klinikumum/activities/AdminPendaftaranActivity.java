package com.klinikumum.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.klinikumum.R;
import com.klinikumum.adapters.PendaftaranAdapter;
import com.klinikumum.models.*;
import com.klinikumum.network.ApiClient;
import com.klinikumum.utils.SessionManager;
import java.text.SimpleDateFormat;
import java.util.*;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminPendaftaranActivity extends AppCompatActivity {

    private SessionManager   session;
    private RecyclerView     rvPendaftaran;
    private ProgressBar      progressBar;
    private SwipeRefreshLayout swipeRefresh;
    private TextView         tvEmpty;
    private PendaftaranAdapter adapter;
    private List<Pendaftaran> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_pendaftaran);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Daftar Antrian Hari Ini");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> finish());

        session       = new SessionManager(this);
        rvPendaftaran = findViewById(R.id.rvPendaftaran);
        progressBar   = findViewById(R.id.progressBar);
        swipeRefresh  = findViewById(R.id.swipeRefresh);
        tvEmpty       = findViewById(R.id.tvEmpty);

        // Adapter dengan tombol Panggil dan Batalkan
        adapter = new PendaftaranAdapter(
                list,
                // Klik item → buka detail
                item -> {
                    Intent intent = new Intent(this, DetailPendaftaranActivity.class);
                    intent.putExtra("pendaftaran_id", item.id);
                    startActivity(intent);
                },
                // Tombol aksi
                new PendaftaranAdapter.OnActionClick() {
                    @Override
                    public void onPanggil(Pendaftaran item) {
                        // Konfirmasi sebelum memanggil
                        new AlertDialog.Builder(AdminPendaftaranActivity.this)
                                .setTitle("Panggil Pasien")
                                .setMessage("Panggil " + item.getNamaDisplay() + " (" + item.noAntrian + ")?")
                                .setPositiveButton("Ya, Panggil", (d, w) ->
                                        updateStatus(item.id, "dipanggil"))
                                .setNegativeButton("Batal", null)
                                .show();
                    }

                    @Override
                    public void onBatal(Pendaftaran item) {
                        // Konfirmasi sebelum membatalkan
                        new AlertDialog.Builder(AdminPendaftaranActivity.this)
                                .setTitle("Batalkan Antrian")
                                .setMessage("Batalkan antrian " + item.getNamaDisplay() + "?")
                                .setPositiveButton("Ya, Batalkan", (d, w) ->
                                        updateStatus(item.id, "batal"))
                                .setNegativeButton("Tidak", null)
                                .show();
                    }
                }
        );

        rvPendaftaran.setLayoutManager(new LinearLayoutManager(this));
        rvPendaftaran.setAdapter(adapter);

        swipeRefresh.setOnRefreshListener(() -> {
            loadData();
            swipeRefresh.setRefreshing(false);
        });

        loadData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }

    // ===== LOAD DATA ANTRIAN =====
    private void loadData() {
        progressBar.setVisibility(View.VISIBLE);
        tvEmpty.setVisibility(View.GONE);

        String token = "Bearer " + session.getToken();
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        ApiClient.getService().getPendaftaranList(token, today)
                .enqueue(new Callback<BaseResponse<List<Pendaftaran>>>() {
                    @Override
                    public void onResponse(Call<BaseResponse<List<Pendaftaran>>> call,
                                           Response<BaseResponse<List<Pendaftaran>>> response) {
                        progressBar.setVisibility(View.GONE);

                        if (response.isSuccessful() && response.body() != null) {
                            if (response.body().status && response.body().data != null) {
                                list.clear();
                                list.addAll(response.body().data);
                                adapter.notifyDataSetChanged();

                                // Tampilkan empty state kalau list kosong
                                tvEmpty.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
                            } else {
                                // Server merespons tapi status false
                                String msg = response.body().message != null
                                        ? response.body().message : "Gagal memuat data";
                                tvEmpty.setText(msg);
                                tvEmpty.setVisibility(View.VISIBLE);
                            }
                        } else {
                            tvEmpty.setText("Gagal memuat data (Error " + response.code() + ")");
                            tvEmpty.setVisibility(View.VISIBLE);
                            Toast.makeText(AdminPendaftaranActivity.this,
                                    "Gagal: " + response.code(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<BaseResponse<List<Pendaftaran>>> call, Throwable t) {
                        progressBar.setVisibility(View.GONE);
                        String errMsg = "Tidak bisa terhubung ke server.\nCek koneksi WiFi dan pastikan XAMPP aktif.";
                        tvEmpty.setText(errMsg);
                        tvEmpty.setVisibility(View.VISIBLE);
                        Toast.makeText(AdminPendaftaranActivity.this,
                                "Koneksi gagal: " + t.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    // ===== UPDATE STATUS (Panggil / Batalkan) =====
    private void updateStatus(int pendaftaranId, String status) {
        progressBar.setVisibility(View.VISIBLE);
        String token = "Bearer " + session.getToken();

        Map<String, Object> body = new HashMap<>();
        body.put("id",     pendaftaranId);
        body.put("status", status);

        ApiClient.getService().updateStatusPendaftaran(token, body)
                .enqueue(new Callback<BaseResponse<Object>>() {
                    @Override
                    public void onResponse(Call<BaseResponse<Object>> call,
                                           Response<BaseResponse<Object>> response) {
                        progressBar.setVisibility(View.GONE);
                        if (response.isSuccessful() && response.body() != null && response.body().status) {
                            String label = "dipanggil".equals(status) ? "Pasien berhasil dipanggil!" : "Antrian dibatalkan.";
                            Toast.makeText(AdminPendaftaranActivity.this, label, Toast.LENGTH_SHORT).show();
                            loadData(); // Refresh list
                        } else {
                            Toast.makeText(AdminPendaftaranActivity.this,
                                    "Gagal update status", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<BaseResponse<Object>> call, Throwable t) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(AdminPendaftaranActivity.this,
                                "Koneksi gagal", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
