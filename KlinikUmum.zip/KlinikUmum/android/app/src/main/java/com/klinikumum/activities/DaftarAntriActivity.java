package com.klinikumum.activities;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.klinikumum.R;
import com.klinikumum.models.*;
import com.klinikumum.network.ApiClient;
import com.klinikumum.utils.SessionManager;
import java.util.*;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DaftarAntriActivity extends AppCompatActivity {

    private Spinner spinnerDokter, spinnerPembayaran, spinnerHubungan;
    private TextInputEditText etKeluhan, etNoBpjs, etNoAsuransi;
    private TextInputEditText etNamaPasienLain, etNoHpPasienLain;
    private MaterialButton btnDaftar, btnUntukSendiri, btnUntukOrangLain, btnKembali;
    private ProgressBar progressBar;
    private TextView tvError, tvNoAntrianResult, tvNamaPasienResult;
    private View layoutBpjs, layoutAsuransi, layoutOrangLain, cardResult;
    private SessionManager session;
    private List<Dokter> dokterList = new ArrayList<>();
    private boolean untukDiriSendiri = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar_antri);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Daftar Antrian");
        toolbar.setNavigationOnClickListener(v -> finish());

        session              = new SessionManager(this);
        spinnerDokter        = findViewById(R.id.spinnerDokter);
        spinnerPembayaran    = findViewById(R.id.spinnerPembayaran);
        spinnerHubungan      = findViewById(R.id.spinnerHubungan);
        etKeluhan            = findViewById(R.id.etKeluhan);
        etNoBpjs             = findViewById(R.id.etNoBpjs);
        etNoAsuransi         = findViewById(R.id.etNoAsuransi);
        etNamaPasienLain     = findViewById(R.id.etNamaPasienLain);
        etNoHpPasienLain     = findViewById(R.id.etNoHpPasienLain);
        btnDaftar            = findViewById(R.id.btnDaftar);
        btnUntukSendiri      = findViewById(R.id.btnUntukSendiri);
        btnUntukOrangLain    = findViewById(R.id.btnUntukOrangLain);
        btnKembali           = findViewById(R.id.btnKembali);
        progressBar          = findViewById(R.id.progressBar);
        tvError              = findViewById(R.id.tvError);
        tvNoAntrianResult    = findViewById(R.id.tvNoAntrianResult);
        tvNamaPasienResult   = findViewById(R.id.tvNamaPasienResult);
        layoutBpjs           = findViewById(R.id.layoutBpjs);
        layoutAsuransi       = findViewById(R.id.layoutAsuransi);
        layoutOrangLain      = findViewById(R.id.layoutOrangLain);
        cardResult           = findViewById(R.id.cardResult);

        // Setup spinner pembayaran
        String[] pembayaranOptions = {"Umum (Bayar Sendiri)", "BPJS", "Asuransi"};
        spinnerPembayaran.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, pembayaranOptions));
        spinnerPembayaran.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                layoutBpjs.setVisibility(pos == 1 ? View.VISIBLE : View.GONE);
                layoutAsuransi.setVisibility(pos == 2 ? View.VISIBLE : View.GONE);
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });

        // Setup spinner hubungan
        String[] hubunganOptions = {"Orang Tua", "Anak", "Kakek/Nenek", "Suami/Istri", "Saudara", "Lainnya"};
        spinnerHubungan.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, hubunganOptions));

        // Toggle diri sendiri vs orang lain
        btnUntukSendiri.setOnClickListener(v -> setUntukSendiri(true));
        btnUntukOrangLain.setOnClickListener(v -> setUntukSendiri(false));
        setUntukSendiri(true); // default

        btnKembali.setOnClickListener(v -> finish());
        btnDaftar.setOnClickListener(v -> doDaftar());
        loadDokter();
    }

    private void setUntukSendiri(boolean sendiri) {
        untukDiriSendiri = sendiri;
        // Update button styles
        btnUntukSendiri.setBackgroundColor(sendiri ?
                getResources().getColor(R.color.primary) :
                getResources().getColor(R.color.divider));
        btnUntukSendiri.setTextColor(sendiri ?
                getResources().getColor(R.color.white) :
                getResources().getColor(R.color.text_secondary));
        btnUntukOrangLain.setBackgroundColor(!sendiri ?
                getResources().getColor(R.color.primary) :
                getResources().getColor(R.color.divider));
        btnUntukOrangLain.setTextColor(!sendiri ?
                getResources().getColor(R.color.white) :
                getResources().getColor(R.color.text_secondary));
        layoutOrangLain.setVisibility(sendiri ? View.GONE : View.VISIBLE);
        tvError.setVisibility(View.GONE);
    }

    private void loadDokter() {
        String token = "Bearer " + session.getToken();
        ApiClient.getService().getDokterList(token).enqueue(new Callback<BaseResponse<List<Dokter>>>() {
            @Override
            public void onResponse(Call<BaseResponse<List<Dokter>>> call,
                                   Response<BaseResponse<List<Dokter>>> response) {
                if (response.isSuccessful() && response.body() != null && response.body().status) {
                    dokterList = response.body().data;
                    List<String> names = new ArrayList<>();
                    for (Dokter d : dokterList) names.add("Dr. " + d.nama + " — " + d.spesialisasi);
                    spinnerDokter.setAdapter(new ArrayAdapter<>(DaftarAntriActivity.this,
                            android.R.layout.simple_spinner_dropdown_item, names));
                }
            }
            @Override public void onFailure(Call<BaseResponse<List<Dokter>>> call, Throwable t) {
                Toast.makeText(DaftarAntriActivity.this, "Gagal memuat dokter", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void doDaftar() {
        tvError.setVisibility(View.GONE);
        String keluhan = etKeluhan.getText().toString().trim();
        if (keluhan.isEmpty()) { showError("Keluhan wajib diisi"); return; }
        if (dokterList.isEmpty()) { showError("Pilih dokter terlebih dahulu"); return; }
        if (!untukDiriSendiri) {
            String namaPasienLain = etNamaPasienLain.getText().toString().trim();
            if (namaPasienLain.isEmpty()) { showError("Nama pasien yang sakit wajib diisi"); return; }
        }

        int dokterPos      = spinnerDokter.getSelectedItemPosition();
        int pembayaranPos  = spinnerPembayaran.getSelectedItemPosition();
        String[] jenis     = {"umum", "bpjs", "asuransi"};
        String[] hubOptions= {"Orang Tua", "Anak", "Kakek/Nenek", "Suami/Istri", "Saudara", "Lainnya"};

        Map<String, Object> body = new HashMap<>();
        body.put("dokter_id",           dokterList.get(dokterPos).id);
        body.put("keluhan",             keluhan);
        body.put("jenis_pembayaran",    jenis[pembayaranPos]);
        body.put("untuk_diri_sendiri",  untukDiriSendiri ? 1 : 0);
        if (pembayaranPos == 1) body.put("no_bpjs",    etNoBpjs.getText().toString().trim());
        if (pembayaranPos == 2) body.put("no_asuransi", etNoAsuransi.getText().toString().trim());
        if (!untukDiriSendiri) {
            body.put("nama_pasien_lain",  etNamaPasienLain.getText().toString().trim());
            body.put("hubungan",          hubOptions[spinnerHubungan.getSelectedItemPosition()]);
            body.put("no_hp_pasien_lain", etNoHpPasienLain.getText().toString().trim());
        }

        setLoading(true);
        String token = "Bearer " + session.getToken();
        ApiClient.getService().daftarAntrian(token, body).enqueue(new Callback<BaseResponse<Object>>() {
            @Override
            public void onResponse(Call<BaseResponse<Object>> call,
                                   Response<BaseResponse<Object>> response) {
                setLoading(false);
                if (response.isSuccessful() && response.body() != null) {
                    if (response.body().status) {
                        // Tampilkan card hasil
                        cardResult.setVisibility(View.VISIBLE);
                        btnDaftar.setVisibility(View.GONE);
                        // Parse data dari message
                        Toast.makeText(DaftarAntriActivity.this,
                                response.body().message, Toast.LENGTH_LONG).show();
                        // Jika server kembalikan data (Nomor Antrian & Nama)
                        if (response.body().data != null) {
                            try {
                                // Ambil data dari map (Retrofit/Gson by default map ke LinkedTreeMap untuk Object)
                                if (response.body().data instanceof Map) {
                                    Map<?, ?> data = (Map<?, ?>) response.body().data;
                                    tvNoAntrianResult.setText(String.valueOf(data.get("no_antrian")));
                                    tvNamaPasienResult.setText(String.valueOf(data.get("nama_pasien")));
                                }
                            } catch (Exception e) {
                                Log.e("DaftarAntri", "Parse result error: " + e.getMessage());
                            }
                        }
                    } else {
                        showError(response.body().message);
                    }
                } else {
                    // HTTP error (4xx / 5xx) atau body null
                    int code = response.code();
                    if (code == 401) {
                        showError("Sesi habis, silakan login ulang");
                    } else if (code >= 500) {
                        showError("Server (PHP) Error 500: Database gagal menyimpan data.\n" +
                                "Pastikan tabel 'pendaftaran' di phpMyAdmin memiliki kolom yang sesuai.");
                    } else {
                        showError("Pendaftaran gagal (kode: " + code + ")");
                    }
                }
            }
            @Override public void onFailure(Call<BaseResponse<Object>> call, Throwable t) {
                setLoading(false);
                Log.e("DaftarAntri", "onFailure: " + t.getMessage(), t);

                if (t instanceof com.google.gson.JsonSyntaxException) {
                    showError("Server Error: Database Error (Respons bukan JSON).\n" +
                            "Cek pendaftaran.php di server, mungkin ada duplikasi data atau kolom kurang.");
                } else {
                    showError("Masalah Koneksi: " + t.getMessage());
                }
            }
        });
    }

    private void showError(String msg) { tvError.setText(msg); tvError.setVisibility(View.VISIBLE); }
    private void setLoading(boolean l) {
        progressBar.setVisibility(l ? View.VISIBLE : View.GONE);
        btnDaftar.setEnabled(!l);
        btnDaftar.setText(l ? "Mendaftarkan..." : "Daftar Sekarang");
    }
}
