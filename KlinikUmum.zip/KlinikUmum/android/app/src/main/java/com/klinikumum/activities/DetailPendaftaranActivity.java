package com.klinikumum.activities;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.klinikumum.R;
import com.klinikumum.models.*;
import com.klinikumum.network.ApiClient;
import com.klinikumum.utils.SessionManager;
import java.util.*;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailPendaftaranActivity extends AppCompatActivity {

    private static final String TAG = "DetailPendaftaran";

    private SessionManager session;
    private int pendaftaranId;
    private ProgressBar progressBar;
    private TextView tvNoAntrian, tvNamaPasien, tvNoRm, tvTanggal, tvKeluhan;
    private TextView tvStatus, tvNamaDokter, tvDiagnosa, tvCatatan;
    private TextView tvTekananDarah, tvSuhu, tvBB, tvTB;
    private TextView tvNoInvoice, tvTotal, tvStatusBayar;
    private View cardPemeriksaan, cardPembayaran, cardResep;
    private LinearLayout layoutResepList;

    private String currentStatus = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_pendaftaran);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Detail Rekam Medis");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        session = new SessionManager(this);
        initViews();

        RiwayatMedis r = (RiwayatMedis) getIntent().getSerializableExtra("riwayat_medis");
        if (r != null) {
            pendaftaranId = r.getSafeId();
            currentStatus = r.status;
            renderFromRiwayat(r);
        } else {
            pendaftaranId = getIntent().getIntExtra("pendaftaran_id", 0);
        }

        if (pendaftaranId <= 0) {
            Toast.makeText(this, "Data tidak ditemukan", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadAllData();
    }

    private void initViews() {
        progressBar        = findViewById(R.id.progressBar);
        tvNoAntrian        = findViewById(R.id.tvNoAntrian);
        tvNamaPasien       = findViewById(R.id.tvNamaPasien);
        tvNoRm             = findViewById(R.id.tvNoRm);
        tvTanggal          = findViewById(R.id.tvTanggal);
        tvKeluhan          = findViewById(R.id.tvKeluhan);
        tvStatus           = findViewById(R.id.tvStatus);
        tvNamaDokter       = findViewById(R.id.tvNamaDokter);
        tvDiagnosa         = findViewById(R.id.tvDiagnosa);
        tvCatatan          = findViewById(R.id.tvCatatan);
        tvTekananDarah     = findViewById(R.id.tvTekananDarah);
        tvSuhu             = findViewById(R.id.tvSuhu);
        tvBB               = findViewById(R.id.tvBB);
        tvTB               = findViewById(R.id.tvTB);
        tvNoInvoice        = findViewById(R.id.tvNoInvoice);
        tvTotal            = findViewById(R.id.tvTotal);
        tvStatusBayar      = findViewById(R.id.tvStatusBayar);
        cardPemeriksaan    = findViewById(R.id.cardPemeriksaan);
        cardPembayaran     = findViewById(R.id.cardPembayaran);
        cardResep          = findViewById(R.id.cardResep);
        layoutResepList    = findViewById(R.id.layoutResepList);

        // Hide cards initially
        cardPemeriksaan.setVisibility(View.GONE);
        cardResep.setVisibility(View.GONE);
        cardPembayaran.setVisibility(View.GONE);
    }

    private void renderFromRiwayat(RiwayatMedis r) {
        tvNoAntrian.setText(r.noAntrian != null ? r.noAntrian : "-");
        tvNamaPasien.setText(r.namaPasien != null ? r.namaPasien : "-");
        tvTanggal.setText(r.tanggal != null ? r.tanggal : "-");
        tvKeluhan.setText(r.keluhan != null ? "Keluhan: " + r.keluhan : "-");
        tvNamaDokter.setText(cleanDrName(r.namaDokter) + (r.spesialisasi != null ? " · " + r.spesialisasi : ""));
        
        tvStatus.setText(getStatusLabel(r.status));
        tvStatus.getBackground().setTint(getStatusColor(r.status));
        tvStatus.setTextColor(Color.WHITE);

        if ("selesai".equals(r.status)) {
            cardPemeriksaan.setVisibility(View.VISIBLE);
            tvDiagnosa.setText("Memuat detail pemeriksaan...");
        }
    }

    private void loadAllData() {
        progressBar.setVisibility(View.VISIBLE);
        String token = "Bearer " + session.getToken();

        // 1. Get Detail Pendaftaran (for basic info & payment)
        ApiClient.getService().getDetailPendaftaran(token, pendaftaranId).enqueue(new Callback<BaseResponse<Pendaftaran>>() {
            @Override
            public void onResponse(Call<BaseResponse<Pendaftaran>> call, Response<BaseResponse<Pendaftaran>> response) {
                if (response.isSuccessful() && response.body() != null && response.body().data != null) {
                    Pendaftaran p = response.body().data;
                    currentStatus = p.status;
                    renderInfoAntrian(p);
                    renderPembayaran(p);
                }
                // Continue to load pemeriksaan regardless of detail success
                loadPemeriksaan(token);
            }
            @Override public void onFailure(Call<BaseResponse<Pendaftaran>> call, Throwable t) {
                loadPemeriksaan(token);
            }
        });
    }

    private void loadPemeriksaan(String token) {
        ApiClient.getService().getPemeriksaan(token, pendaftaranId).enqueue(new Callback<BaseResponse<Pemeriksaan>>() {
            @Override
            public void onResponse(Call<BaseResponse<Pemeriksaan>> call, Response<BaseResponse<Pemeriksaan>> response) {
                progressBar.setVisibility(View.GONE);
                if (response.isSuccessful() && response.body() != null && response.body().data != null) {
                    Pemeriksaan pm = response.body().data;
                    renderPemeriksaanUI(pm.tekananDarah, pm.suhu, pm.beratBadan, pm.tinggiBadan, pm.diagnosa, pm.catatan);
                    if (pm.resep != null && !pm.resep.isEmpty()) renderResep(pm.resep);
                } else {
                    if ("selesai".equals(currentStatus)) {
                        cardPemeriksaan.setVisibility(View.VISIBLE);
                        tvDiagnosa.setText("Detail pemeriksaan belum tersedia di server.");
                    }
                }
            }
            @Override public void onFailure(Call<BaseResponse<Pemeriksaan>> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                if ("selesai".equals(currentStatus)) {
                    cardPemeriksaan.setVisibility(View.VISIBLE);
                    tvDiagnosa.setText("Gagal mengambil data pemeriksaan.");
                }
            }
        });
    }

    private void renderInfoAntrian(Pendaftaran p) {
        tvNoAntrian.setText(p.noAntrian);
        if (notEmpty(p.getNamaDisplay()) && !"-".equals(p.getNamaDisplay())) {
            tvNamaPasien.setText(p.getNamaDisplay());
        }
        if (p.noRm != null) tvNoRm.setText("No. RM: " + p.noRm);
        tvTanggal.setText(p.tanggal);
        tvKeluhan.setText("Keluhan: " + p.keluhan);
        tvNamaDokter.setText(cleanDrName(p.namaDokter) + (p.spesialisasi != null ? " · " + p.spesialisasi : ""));
        tvStatus.setText(p.getStatusLabel());
        tvStatus.getBackground().setTint(getStatusColor(p.status));
    }

    private void renderPemeriksaanUI(String td, Float suhu, Float bb, Float tb, String diag, String cat) {
        cardPemeriksaan.setVisibility(View.VISIBLE);
        tvTekananDarah.setText(notEmpty(td) ? td : "-");
        tvSuhu.setText(suhu != null && suhu > 0 ? String.format(Locale.getDefault(), "%.1f °C", suhu) : "-");
        tvBB.setText(bb != null && bb > 0 ? String.format(Locale.getDefault(), "%.1f kg", bb) : "-");
        tvTB.setText(tb != null && tb > 0 ? String.format(Locale.getDefault(), "%.0f cm", tb) : "-");
        tvDiagnosa.setText(notEmpty(diag) ? diag : "(belum diisi)");
        tvCatatan.setText(notEmpty(cat) ? "Catatan: " + cat : "");
    }

    private void renderResep(List<Resep> resepList) {
        cardResep.setVisibility(View.VISIBLE);
        layoutResepList.removeAllViews();
        for (Resep r : resepList) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(0, 8, 0, 8);
            
            TextView t1 = new TextView(this);
            t1.setText("💊 " + r.namaObat + " (x" + r.jumlah + ")");
            t1.setTextSize(14f); t1.setTypeface(null, android.graphics.Typeface.BOLD);
            t1.setTextColor(Color.parseColor("#1A237E"));
            
            TextView t2 = new TextView(this);
            t2.setText("Dosis: " + r.dosis + " | Aturan: " + r.aturanPakai);
            t2.setTextSize(13f); t2.setTextColor(Color.parseColor("#555555"));
            
            row.addView(t1);
            row.addView(t2);
            layoutResepList.addView(row);
        }
    }

    private void renderPembayaran(Pendaftaran p) {
        if (notEmpty(p.noInvoice)) {
            cardPembayaran.setVisibility(View.VISIBLE);
            tvNoInvoice.setText("Invoice: " + p.noInvoice);
            tvTotal.setText("Rp " + String.format(Locale.getDefault(), "%,.0f", p.total != null ? p.total : 0));
            tvStatusBayar.setText("belum_bayar".equals(p.statusBayar) ? "Belum Lunas" : "Lunas");
            tvStatusBayar.setTextColor("belum_bayar".equals(p.statusBayar) ? Color.RED : Color.parseColor("#2E7D32"));
        }
    }

    private String cleanDrName(String name) {
        if (name == null || name.equals("-")) return "-";
        String n = name.trim();
        if (n.toLowerCase().startsWith("dr. ")) return n;
        if (n.toLowerCase().startsWith("dr.")) return "Dr. " + n.substring(3).trim();
        return "Dr. " + n;
    }

    private String getStatusLabel(String s) {
        if (s == null) return "-";
        switch (s) {
            case "menunggu": return "Menunggu";
            case "dipanggil": return "Dipanggil";
            case "selesai": return "Selesai";
            case "batal": return "Batal";
            default: return s;
        }
    }

    private int getStatusColor(String s) {
        if (s == null) return Color.GRAY;
        switch (s) {
            case "menunggu": return Color.parseColor("#E65100");
            case "dipanggil": return Color.parseColor("#1565C0");
            case "selesai": return Color.parseColor("#2E7D32");
            case "batal": return Color.parseColor("#C62828");
            default: return Color.GRAY;
        }
    }

    private boolean notEmpty(String s) { return s != null && !s.isEmpty(); }
}
