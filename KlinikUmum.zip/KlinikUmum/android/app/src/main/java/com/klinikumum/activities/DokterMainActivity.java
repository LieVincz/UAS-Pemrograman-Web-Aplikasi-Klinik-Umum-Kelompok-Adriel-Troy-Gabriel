package com.klinikumum.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.klinikumum.R;
import com.klinikumum.adapters.PendaftaranAdapter;
import com.klinikumum.models.*;
import com.klinikumum.network.ApiClient;
import com.klinikumum.utils.SessionManager;
import java.text.SimpleDateFormat;
import java.util.*;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DokterMainActivity extends AppCompatActivity {

    private SessionManager session;
    private TextView tvNamaDokter, tvPasienHariIni, tvMenunggu;
    private RecyclerView rvAntrian;
    private SwipeRefreshLayout swipeRefresh;
    private ProgressBar progressBar;
    private PendaftaranAdapter adapter;
    private List<Pendaftaran> antrianList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dokter_main);

        session = new SessionManager(this);

        tvNamaDokter   = findViewById(R.id.tvNamaDokter);
        tvPasienHariIni= findViewById(R.id.tvPasienHariIni);
        tvMenunggu     = findViewById(R.id.tvMenunggu);
        rvAntrian      = findViewById(R.id.rvAntrian);
        swipeRefresh   = findViewById(R.id.swipeRefresh);
        progressBar    = findViewById(R.id.progressBar);

        tvNamaDokter.setText("Dr. " + session.getNama());

        adapter = new PendaftaranAdapter(antrianList, item -> {
            Intent intent = new Intent(this, PemeriksaanActivity.class);
            intent.putExtra("pendaftaran_id", item.id);
            intent.putExtra("nama_pasien", item.namaPasien);
            intent.putExtra("no_rm", item.noRm);
            startActivity(intent);
        });
        rvAntrian.setLayoutManager(new LinearLayoutManager(this));
        rvAntrian.setAdapter(adapter);

        swipeRefresh.setOnRefreshListener(() -> { loadData(); swipeRefresh.setRefreshing(false); });

        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_profil) {
                startActivity(new Intent(this, ProfilActivity.class));
            }
            return true;
        });

        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            session.logout();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        loadData();
    }

    @Override protected void onResume() { super.onResume(); loadData(); }

    private void loadData() {
        progressBar.setVisibility(View.VISIBLE);
        String token = "Bearer " + session.getToken();
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        ApiClient.getService().getDashboard(token).enqueue(new Callback<BaseResponse<DashboardData>>() {
            @Override
            public void onResponse(Call<BaseResponse<DashboardData>> call, Response<BaseResponse<DashboardData>> response) {
                progressBar.setVisibility(View.GONE);
                if (response.isSuccessful() && response.body() != null && response.body().status) {
                    DashboardData data = response.body().data;
                    tvPasienHariIni.setText(String.valueOf(data.pasienHariIni));
                    tvMenunggu.setText(String.valueOf(data.antrianMenunggu));
                    antrianList.clear();
                    if (data.antrianList != null) antrianList.addAll(data.antrianList);
                    adapter.notifyDataSetChanged();
                }
            }
            @Override
            public void onFailure(Call<BaseResponse<DashboardData>> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
            }
        });
    }
}
