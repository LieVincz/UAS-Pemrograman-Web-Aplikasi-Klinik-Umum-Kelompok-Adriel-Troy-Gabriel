package com.klinikumum.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.klinikumum.R;
import com.klinikumum.models.*;
import com.klinikumum.network.ApiClient;
import com.klinikumum.utils.SessionManager;
import java.util.HashMap;
import java.util.Map;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etEmail, etPassword;
    private MaterialButton btnLogin;
    private TextView tvRegister, tvError;
    private LinearLayout layoutError;
    private ProgressBar progressBar;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        session = new SessionManager(this);
        if (session.isLoggedIn()) {
            redirectByRole(session.getRole());
            return;
        }

        etEmail    = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin   = findViewById(R.id.btnLogin);
        tvRegister = findViewById(R.id.tvRegister);
        tvError    = findViewById(R.id.tvError);
        layoutError= findViewById(R.id.layoutError);
        progressBar= findViewById(R.id.progressBar);

        btnLogin.setOnClickListener(v -> doLogin());
        tvRegister.setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class)));
    }

    private void doLogin() {
        String email    = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            showError("Email dan password wajib diisi");
            return;
        }

        setLoading(true);
        Map<String, String> body = new HashMap<>();
        body.put("email", email);
        body.put("password", password);

        ApiClient.getService().login(body).enqueue(new Callback<BaseResponse<LoginData>>() {
            @Override
            public void onResponse(Call<BaseResponse<LoginData>> call, Response<BaseResponse<LoginData>> response) {
                setLoading(false);
                if (response.isSuccessful() && response.body() != null) {
                    BaseResponse<LoginData> res = response.body();
                    if (res.status && res.data != null) {
                        UserProfil user = res.data.user;
                        session.saveSession(
                                res.data.token,
                                user.id,
                                user.nama,
                                user.email,
                                user.role,
                                user.pasienId,
                                user.dokterId,
                                user.noRm
                        );
                        redirectByRole(user.role);
                    } else {
                        showError(res.message);
                    }
                } else {
                    showError("Gagal terhubung ke server");
                }
            }

            @Override
            public void onFailure(Call<BaseResponse<LoginData>> call, Throwable t) {
                setLoading(false);
                showError("Error: " + t.getMessage());
            }
        });
    }

    private void redirectByRole(String role) {
        Intent intent;
        switch (role) {
            case "admin":  intent = new Intent(this, AdminMainActivity.class); break;
            case "dokter": intent = new Intent(this, DokterMainActivity.class); break;
            default:       intent = new Intent(this, PasienMainActivity.class);
        }
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    private void showError(String msg) {
        tvError.setText(msg);
        layoutError.setVisibility(View.VISIBLE);
    }

    private void setLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnLogin.setEnabled(!loading);
        btnLogin.setText(loading ? "Memuat..." : "Masuk");
    }
}
