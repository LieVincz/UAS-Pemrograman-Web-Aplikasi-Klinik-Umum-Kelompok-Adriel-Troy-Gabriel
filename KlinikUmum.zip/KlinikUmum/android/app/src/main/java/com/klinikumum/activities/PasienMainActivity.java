package com.klinikumum.activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.klinikumum.R;
import com.klinikumum.models.*;
import com.klinikumum.network.ApiClient;
import com.klinikumum.utils.SessionManager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PasienMainActivity extends AppCompatActivity {

    private SessionManager session;
    private TextView tvNama, tvNoRm, tvNoAntrianBanner;
    private CardView cardAntrianBanner;
    private LinearLayout navRiwayat, navAntrian, navProfil;
    private LinearLayout layoutTips;

    // Tips kesehatan data
    private static final String[][] TIPS = {
            {"💧", "Minum Air Putih", "Minum minimal 8 gelas air per hari untuk menjaga tubuh tetap terhidrasi dan organ berfungsi optimal."},
            {"🥗", "Makan Bergizi", "Konsumsi sayur, buah, protein, dan karbohidrat seimbang setiap hari untuk imun tubuh yang kuat."},
            {"🏃", "Olahraga Rutin", "Lakukan aktivitas fisik 30 menit sehari, minimal 3x seminggu untuk menjaga kesehatan jantung."},
            {"😴", "Tidur Cukup", "Tidur 7–8 jam per malam membantu pemulihan tubuh dan menjaga kesehatan mental."},
            {"🧴", "Cuci Tangan", "Cuci tangan dengan sabun selama 20 detik sebelum makan dan setelah dari toilet untuk mencegah penyakit."},
            {"🚭", "Hindari Rokok", "Tidak merokok melindungi paru-paru dan mengurangi risiko kanker, penyakit jantung, dan stroke."},
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pasien_main);

        session = new SessionManager(this);

        tvNama            = findViewById(R.id.tvNama);
        tvNoRm            = findViewById(R.id.tvNoRm);
        tvNoAntrianBanner = findViewById(R.id.tvNoAntrianBanner);
        cardAntrianBanner = findViewById(R.id.cardAntrianBanner);
        navRiwayat        = findViewById(R.id.navRiwayat);
        navAntrian        = findViewById(R.id.navAntrian);
        navProfil         = findViewById(R.id.navProfil);
        layoutTips        = findViewById(R.id.layoutTips);

        // Set nama & no RM
        tvNama.setText(session.getNama());
        String noRm = session.getNoRm();
        tvNoRm.setText(noRm != null && !noRm.isEmpty() ? "No. RM: " + noRm : "");

        // Setup kartu layanan
        CardView cardAmbilAntrian = findViewById(R.id.cardAmbilAntrian);
        CardView cardDetailPemeriksaan = findViewById(R.id.cardDetailPemeriksaan);

        cardAmbilAntrian.setOnClickListener(v -> showAntrianWarning());
        cardDetailPemeriksaan.setOnClickListener(v -> {
            Intent intent = new Intent(this, RiwayatActivity.class);
            intent.putExtra("mode_selection", true);
            startActivity(intent);
        });

        // Banner antrian aktif → ke riwayat antrian
        cardAntrianBanner.setOnClickListener(v ->
                startActivity(new Intent(this, RiwayatActivity.class)));

        // Bottom navbar
        navRiwayat.setOnClickListener(v ->
                startActivity(new Intent(this, RiwayatActivity.class)));

        navAntrian.setOnClickListener(v -> showAntrianWarning());

        navProfil.setOnClickListener(v ->
                startActivity(new Intent(this, ProfilActivity.class)));

        // Build tips cards
        buildTipsCards();

        // Load dashboard data
        loadDashboard();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDashboard();
    }

    private void buildTipsCards() {
        layoutTips.removeAllViews();
        int[] bgColors = {
                Color.parseColor("#E3F2FD"), Color.parseColor("#E8F5E9"),
                Color.parseColor("#FFF3E0"), Color.parseColor("#F3E5F5"),
                Color.parseColor("#E0F7FA"), Color.parseColor("#FBE9E7")
        };
        int[] textColors = {
                Color.parseColor("#1565C0"), Color.parseColor("#2E7D32"),
                Color.parseColor("#E65100"), Color.parseColor("#6A1B9A"),
                Color.parseColor("#00838F"), Color.parseColor("#BF360C")
        };

        for (int i = 0; i < TIPS.length; i++) {
            final String[] tip = TIPS[i];

            // Card container
            CardView card = new CardView(this);
            CardView.LayoutParams cardParams = new CardView.LayoutParams(
                    (int) (220 * getResources().getDisplayMetrics().density),
                    CardView.LayoutParams.WRAP_CONTENT
            );
            cardParams.setMarginEnd((int) (10 * getResources().getDisplayMetrics().density));
            card.setLayoutParams(cardParams);
            card.setRadius(16 * getResources().getDisplayMetrics().density);
            card.setCardElevation(4 * getResources().getDisplayMetrics().density);
            card.setCardBackgroundColor(bgColors[i % bgColors.length]);

            // Inner layout
            LinearLayout inner = new LinearLayout(this);
            inner.setOrientation(LinearLayout.VERTICAL);
            int pad = (int) (14 * getResources().getDisplayMetrics().density);
            inner.setPadding(pad, pad, pad, pad);

            // Emoji + judul row
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);

            TextView tvEmoji = new TextView(this);
            tvEmoji.setText(tip[0]);
            tvEmoji.setTextSize(22);
            LinearLayout.LayoutParams emojiParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            emojiParams.setMarginEnd((int)(8 * getResources().getDisplayMetrics().density));
            tvEmoji.setLayoutParams(emojiParams);

            TextView tvJudul = new TextView(this);
            tvJudul.setText(tip[1]);
            tvJudul.setTextSize(13);
            tvJudul.setTextColor(textColors[i % textColors.length]);
            tvJudul.setTypeface(null, android.graphics.Typeface.BOLD);
            tvJudul.setLayoutParams(new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            row.addView(tvEmoji);
            row.addView(tvJudul);

            // Deskripsi
            TextView tvDesc = new TextView(this);
            tvDesc.setText(tip[2]);
            tvDesc.setTextSize(12);
            tvDesc.setTextColor(Color.parseColor("#546E7A"));
            LinearLayout.LayoutParams descParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            descParams.topMargin = (int)(6 * getResources().getDisplayMetrics().density);
            tvDesc.setLayoutParams(descParams);
            tvDesc.setMaxLines(3);
            tvDesc.setEllipsize(android.text.TextUtils.TruncateAt.END);

            inner.addView(row);
            inner.addView(tvDesc);
            card.addView(inner);
            layoutTips.addView(card);
        }
    }

    private void loadDashboard() {
        String token = "Bearer " + session.getToken();
        ApiClient.getService().getDashboard(token).enqueue(new Callback<BaseResponse<DashboardData>>() {
            @Override
            public void onResponse(Call<BaseResponse<DashboardData>> call,
                                   Response<BaseResponse<DashboardData>> response) {
                if (response.isSuccessful() && response.body() != null && response.body().status) {
                    DashboardData data = response.body().data;

                    // Banner antrian aktif
                    if (data.antrianAktif != null) {
                        cardAntrianBanner.setVisibility(View.VISIBLE);
                        String status = data.antrianAktif.getStatusLabel();
                        tvNoAntrianBanner.setText(
                                data.antrianAktif.noAntrian + "  •  " + status);
                    } else {
                        cardAntrianBanner.setVisibility(View.GONE);
                    }
                }
            }
            @Override
            public void onFailure(Call<BaseResponse<DashboardData>> call, Throwable t) {
                // silent fail — tidak perlu toast di homepage
            }
        });
    }

    private void showAntrianWarning() {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Peringatan Antrian")
                .setMessage("Nomor antrian yang akan di ambil berlaku selama 1 jam apabila lebih dari satu jam maka antrian akan dibatalkan. Terima Kasih")
                .setPositiveButton("Lanjutkan", (dialog, which) -> {
                    startActivity(new Intent(this, DaftarAntriActivity.class));
                })
                .setNegativeButton("Batal", null)
                .show();
    }
}
