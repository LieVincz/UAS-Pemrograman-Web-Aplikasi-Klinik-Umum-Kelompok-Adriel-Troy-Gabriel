package com.klinikumum.activities;

import android.graphics.Color;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.klinikumum.R;
import com.klinikumum.models.*;
import com.klinikumum.network.ApiClient;
import com.klinikumum.utils.SessionManager;
import java.util.*;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PemeriksaanActivity extends AppCompatActivity {

    private SessionManager session;
    private int pendaftaranId;
    private TextInputEditText etTekananDarah, etSuhu, etBeratBadan, etTinggiBadan, etDiagnosa, etCatatan;
    private TextInputEditText etNamaObat, etDosis, etAturanPakai, etJumlah, etKeteranganResep;
    private MaterialButton btnSimpanPeriksa, btnSaranResep;
    private LinearLayout layoutResepList;
    private ProgressBar progressBar;
    private TextView tvNamaPasien, tvNoRm, tvError;
    private int pemeriksaanId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pemeriksaan);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Input Pemeriksaan");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> finish());

        session        = new SessionManager(this);
        pendaftaranId  = getIntent().getIntExtra("pendaftaran_id", 0);
        String namaPasien = getIntent().getStringExtra("nama_pasien");
        String noRm = getIntent().getStringExtra("no_rm");

        tvNamaPasien   = findViewById(R.id.tvNamaPasien);
        tvNoRm         = findViewById(R.id.tvNoRm);
        etTekananDarah = findViewById(R.id.etTekananDarah);
        etSuhu         = findViewById(R.id.etSuhu);
        etBeratBadan   = findViewById(R.id.etBeratBadan);
        etTinggiBadan  = findViewById(R.id.etTinggiBadan);
        etDiagnosa     = findViewById(R.id.etDiagnosa);
        etCatatan      = findViewById(R.id.etCatatan);
        etNamaObat     = findViewById(R.id.etNamaObat);
        etDosis        = findViewById(R.id.etDosis);
        etAturanPakai  = findViewById(R.id.etAturanPakai);
        etJumlah       = findViewById(R.id.etJumlah);
        etKeteranganResep = findViewById(R.id.etKeteranganResep);
        btnSimpanPeriksa = findViewById(R.id.btnSimpanPeriksa);
        btnSaranResep = findViewById(R.id.btnSaranResep);
        layoutResepList= findViewById(R.id.layoutResepList);
        progressBar    = findViewById(R.id.progressBar);
        tvError        = findViewById(R.id.tvError);

        tvNamaPasien.setText(namaPasien != null ? namaPasien : "-");
        tvNoRm.setText(noRm != null ? "No. RM: " + noRm : "");

        btnSimpanPeriksa.setOnClickListener(v -> simpanPemeriksaan());
        btnSaranResep.setOnClickListener(v -> tambahResep());

        loadPemeriksaan();
    }

    private void loadPemeriksaan() {
        String token = "Bearer " + session.getToken();
        ApiClient.getService().getPemeriksaan(token, pendaftaranId).enqueue(new Callback<BaseResponse<Pemeriksaan>>() {
            @Override
            public void onResponse(Call<BaseResponse<Pemeriksaan>> call, Response<BaseResponse<Pemeriksaan>> response) {
                if (response.isSuccessful() && response.body() != null && response.body().data != null) {
                    Pemeriksaan p = response.body().data;
                    pemeriksaanId = p.id;
                    etTekananDarah.setText(p.tekananDarah);
                    etSuhu.setText(p.suhu != null && p.suhu > 0 ? String.valueOf(p.suhu) : "");
                    etBeratBadan.setText(p.beratBadan != null && p.beratBadan > 0 ? String.valueOf(p.beratBadan) : "");
                    etTinggiBadan.setText(p.tinggiBadan != null && p.tinggiBadan > 0 ? String.valueOf(p.tinggiBadan) : "");
                    etDiagnosa.setText(p.diagnosa);
                    etCatatan.setText(p.catatan);
                    tampilkanResep(p.resep);
                }
            }
            @Override public void onFailure(Call<BaseResponse<Pemeriksaan>> call, Throwable t) {}
        });
    }

    private void simpanPemeriksaan() {
        String diagnosa = etDiagnosa.getText().toString().trim();
        if (diagnosa.isEmpty()) { showError("Diagnosa wajib diisi"); return; }

        Map<String, Object> body = new HashMap<>();
        body.put("pendaftaran_id", pendaftaranId);
        body.put("tekanan_darah", etTekananDarah.getText().toString().trim());
        body.put("suhu", safeFloat(etSuhu.getText().toString()));
        body.put("berat_badan", safeFloat(etBeratBadan.getText().toString()));
        body.put("tinggi_badan", safeFloat(etTinggiBadan.getText().toString()));
        body.put("diagnosa", diagnosa);
        body.put("catatan", etCatatan.getText().toString().trim());

        setLoading(true);
        String token = "Bearer " + session.getToken();
        ApiClient.getService().simpanPemeriksaan(token, body).enqueue(new Callback<BaseResponse<Object>>() {
            @Override
            public void onResponse(Call<BaseResponse<Object>> call, Response<BaseResponse<Object>> response) {
                setLoading(false);
                if (response.isSuccessful() && response.body() != null) {
                    Toast.makeText(PemeriksaanActivity.this, response.body().message, Toast.LENGTH_SHORT).show();
                    if (response.body().status) {
                        tvError.setVisibility(View.GONE);
                        loadPemeriksaan();
                    } else {
                        showError(response.body().message);
                    }
                }
            }
            @Override public void onFailure(Call<BaseResponse<Object>> call, Throwable t) {
                setLoading(false);
                showError("Gagal terhubung ke server");
            }
        });
    }

    private void tambahResep() {
        if (pemeriksaanId == 0) {
            showError("Simpan pemeriksaan dulu sebelum tambah resep");
            return;
        }
        String namaObat = etNamaObat.getText().toString().trim();
        if (namaObat.isEmpty()) { showError("Nama obat wajib diisi"); return; }

        Map<String, Object> body = new HashMap<>();
        body.put("pemeriksaan_id", pemeriksaanId);
        body.put("nama_obat", namaObat);
        body.put("dosis", etDosis.getText().toString().trim());
        body.put("aturan_pakai", etAturanPakai.getText().toString().trim());
        body.put("jumlah", safeInt(etJumlah.getText().toString()));
        body.put("keterangan", etKeteranganResep.getText().toString().trim());

        String token = "Bearer " + session.getToken();
        ApiClient.getService().tambahResep(token, body).enqueue(new Callback<BaseResponse<Object>>() {
            @Override
            public void onResponse(Call<BaseResponse<Object>> call, Response<BaseResponse<Object>> response) {
                if (response.isSuccessful() && response.body() != null && response.body().status) {
                    Toast.makeText(PemeriksaanActivity.this, "Resep ditambahkan", Toast.LENGTH_SHORT).show();
                    etNamaObat.setText(""); etDosis.setText(""); etAturanPakai.setText("");
                    etJumlah.setText(""); etKeteranganResep.setText("");
                    tvError.setVisibility(View.GONE);
                    loadPemeriksaan();
                } else {
                    showError(response.body() != null ? response.body().message : "Gagal tambah resep");
                }
            }
            @Override public void onFailure(Call<BaseResponse<Object>> call, Throwable t) {
                showError("Gagal terhubung ke server");
            }
        });
    }

    private void hapusResep(int resepId, String namaObat) {
        new AlertDialog.Builder(this)
                .setTitle("Hapus Resep")
                .setMessage("Hapus resep \"" + namaObat + "\"?")
                .setPositiveButton("Hapus", (dialog, which) -> {
                    Map<String, Object> body = new HashMap<>();
                    body.put("id", resepId);
                    String token = "Bearer " + session.getToken();
                    ApiClient.getService().hapusResep(token, body).enqueue(new Callback<BaseResponse<Object>>() {
                        @Override
                        public void onResponse(Call<BaseResponse<Object>> call, Response<BaseResponse<Object>> response) {
                            Toast.makeText(PemeriksaanActivity.this, "Resep dihapus", Toast.LENGTH_SHORT).show();
                            loadPemeriksaan();
                        }
                        @Override public void onFailure(Call<BaseResponse<Object>> call, Throwable t) {
                            showError("Gagal menghapus resep");
                        }
                    });
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void tampilkanResep(List<Resep> resepList) {
        layoutResepList.removeAllViews();
        if (resepList == null || resepList.isEmpty()) {
            TextView tvEmpty = new TextView(this);
            tvEmpty.setText("Belum ada resep ditambahkan");
            tvEmpty.setTextColor(Color.parseColor("#9E9E9E"));
            tvEmpty.setTextSize(13f);
            tvEmpty.setPadding(8, 4, 8, 4);
            layoutResepList.addView(tvEmpty);
            return;
        }
        for (Resep r : resepList) {
            // Container per item
            LinearLayout itemLayout = new LinearLayout(this);
            itemLayout.setOrientation(LinearLayout.HORIZONTAL);
            itemLayout.setGravity(android.view.Gravity.CENTER_VERTICAL);
            itemLayout.setPadding(10, 10, 10, 10);

            // Teks resep
            TextView tv = new TextView(this);
            StringBuilder sb = new StringBuilder();
            sb.append("💊 ").append(r.namaObat);
            if (r.dosis != null && !r.dosis.isEmpty()) sb.append(" — ").append(r.dosis);
            if (r.aturanPakai != null && !r.aturanPakai.isEmpty()) sb.append(" | ").append(r.aturanPakai);
            sb.append(" (x").append(r.jumlah).append(")");
            if (r.keterangan != null && !r.keterangan.isEmpty()) sb.append("\n   ").append(r.keterangan);
            tv.setText(sb.toString());
            tv.setTextSize(13f);
            tv.setTextColor(Color.parseColor("#333333"));
            tv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            // Tombol hapus
            Button btnHapus = new Button(this);
            btnHapus.setText("✕");
            btnHapus.setTextColor(Color.WHITE);
            btnHapus.setTextSize(11f);
            btnHapus.setBackgroundColor(Color.parseColor("#F44336"));
            btnHapus.setPadding(16, 4, 16, 4);
            LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            btnParams.setMarginStart(8);
            btnHapus.setLayoutParams(btnParams);
            btnHapus.setOnClickListener(v -> hapusResep(r.id, r.namaObat));

            itemLayout.addView(tv);
            itemLayout.addView(btnHapus);

            // Divider
            View divider = new View(this);
            divider.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 1));
            divider.setBackgroundColor(Color.parseColor("#EEEEEE"));

            layoutResepList.addView(itemLayout);
            layoutResepList.addView(divider);
        }
    }

    private float safeFloat(String s) { try { return Float.parseFloat(s); } catch (Exception e) { return 0; } }
    private int safeInt(String s) { try { return Integer.parseInt(s); } catch (Exception e) { return 1; } }
    private void showError(String msg) {
        tvError.setText(msg);
        tvError.setVisibility(View.VISIBLE);
    }
    private void setLoading(boolean l) {
        progressBar.setVisibility(l ? View.VISIBLE : View.GONE);
        btnSimpanPeriksa.setEnabled(!l);
    }
}
