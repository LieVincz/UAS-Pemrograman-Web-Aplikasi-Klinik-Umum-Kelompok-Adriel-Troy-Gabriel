package com.klinikumum.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.klinikumum.R;
import com.klinikumum.models.*;
import com.klinikumum.network.ApiClient;
import com.klinikumum.utils.SessionManager;
import java.util.*;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfilActivity extends AppCompatActivity {

    private SessionManager session;
    private TextInputEditText etNama, etTelepon, etAlamat;
    private TextView tvEmail, tvRole, tvNoRm;
    private MaterialButton btnSimpan, btnLogout;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Profil Saya");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> finish());

        session     = new SessionManager(this);
        etNama      = findViewById(R.id.etNama);
        etTelepon   = findViewById(R.id.etTelepon);
        etAlamat    = findViewById(R.id.etAlamat);
        tvEmail     = findViewById(R.id.tvEmail);
        tvRole      = findViewById(R.id.tvRole);
        tvNoRm      = findViewById(R.id.tvNoRm);
        btnSimpan   = findViewById(R.id.btnSimpan);
        btnLogout   = findViewById(R.id.btnLogout);
        progressBar = findViewById(R.id.progressBar);

        tvEmail.setText(session.getEmail());
        String role = session.getRole();
        tvRole.setText(role.substring(0, 1).toUpperCase() + role.substring(1));
        tvNoRm.setText(session.isPasien() ? "No. RM: " + session.getNoRm() : "");
        tvNoRm.setVisibility(session.isPasien() ? View.VISIBLE : View.GONE);

        loadProfil();

        btnSimpan.setOnClickListener(v -> simpanProfil());
        btnLogout.setOnClickListener(v -> {
            session.logout();
            Intent intent = new Intent(this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });
    }

    private void loadProfil() {
        String token = "Bearer " + session.getToken();
        ApiClient.getService().getProfil(token).enqueue(new Callback<BaseResponse<UserProfil>>() {
            @Override
            public void onResponse(Call<BaseResponse<UserProfil>> call, Response<BaseResponse<UserProfil>> response) {
                if (response.isSuccessful() && response.body() != null && response.body().status) {
                    UserProfil u = response.body().data;
                    etNama.setText(u.nama);
                    etTelepon.setText(u.noTelepon);
                    etAlamat.setText(u.alamat);
                }
            }
            @Override public void onFailure(Call<BaseResponse<UserProfil>> call, Throwable t) {}
        });
    }

    private void simpanProfil() {
        progressBar.setVisibility(View.VISIBLE);
        btnSimpan.setEnabled(false);
        Map<String, String> body = new HashMap<>();
        body.put("nama", etNama.getText().toString().trim());
        body.put("no_telepon", etTelepon.getText().toString().trim());
        body.put("alamat", etAlamat.getText().toString().trim());

        String token = "Bearer " + session.getToken();
        ApiClient.getService().editProfil(token, body).enqueue(new Callback<BaseResponse<Object>>() {
            @Override
            public void onResponse(Call<BaseResponse<Object>> call, Response<BaseResponse<Object>> response) {
                progressBar.setVisibility(View.GONE);
                btnSimpan.setEnabled(true);
                Toast.makeText(ProfilActivity.this,
                        response.body() != null ? response.body().message : "Tersimpan",
                        Toast.LENGTH_SHORT).show();
            }
            @Override public void onFailure(Call<BaseResponse<Object>> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                btnSimpan.setEnabled(true);
            }
        });
    }
}
