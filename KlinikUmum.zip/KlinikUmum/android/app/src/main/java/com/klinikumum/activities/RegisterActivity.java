package com.klinikumum.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.klinikumum.R;
import com.klinikumum.models.BaseResponse;
import com.klinikumum.network.ApiClient;
import java.util.HashMap;
import java.util.Map;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {

    private TextInputEditText etNama, etEmail, etPassword, etTelepon, etTanggalLahir;
    private RadioGroup rgJenisKelamin;
    private RadioButton rbLaki, rbPerempuan;
    private MaterialButton btnRegister;
    private TextView tvLogin, tvError;
    private LinearLayout layoutError;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etNama         = findViewById(R.id.etNama);
        etEmail        = findViewById(R.id.etEmail);
        etPassword     = findViewById(R.id.etPassword);
        etTelepon      = findViewById(R.id.etTelepon);
        etTanggalLahir = findViewById(R.id.etTanggalLahir);
        rgJenisKelamin = findViewById(R.id.rgJenisKelamin);
        rbLaki         = findViewById(R.id.rbLaki);
        rbPerempuan    = findViewById(R.id.rbPerempuan);
        btnRegister    = findViewById(R.id.btnRegister);
        tvLogin        = findViewById(R.id.tvLogin);
        tvError        = findViewById(R.id.tvError);
        layoutError    = findViewById(R.id.layoutError);
        progressBar    = findViewById(R.id.progressBar);

        btnRegister.setOnClickListener(v -> doRegister());
        tvLogin.setOnClickListener(v -> finish());
    }

    private void doRegister() {
        String nama  = etNama.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String pass  = etPassword.getText().toString().trim();
        String hp    = etTelepon.getText().toString().trim();
        String tl    = etTanggalLahir.getText().toString().trim();
        String jk    = (rgJenisKelamin.getCheckedRadioButtonId() == R.id.rbLaki) ? "L" : "P";

        if (nama.isEmpty())  { showError("Nama lengkap wajib diisi"); return; }
        if (email.isEmpty()) { showError("Email wajib diisi"); return; }
        if (pass.length() < 6) { showError("Password minimal 6 karakter"); return; }

        setLoading(true);
        Map<String, String> body = new HashMap<>();
        body.put("nama", nama);
        body.put("email", email);
        body.put("password", pass);
        body.put("no_telepon", hp);
        body.put("tanggal_lahir", tl);
        body.put("jenis_kelamin", jk);

        ApiClient.getService().register(body).enqueue(new Callback<BaseResponse<Object>>() {
            @Override
            public void onResponse(Call<BaseResponse<Object>> call,
                                   Response<BaseResponse<Object>> response) {
                setLoading(false);
                if (response.isSuccessful() && response.body() != null) {
                    if (response.body().status) {
                        Toast.makeText(RegisterActivity.this,
                                "Registrasi berhasil! Silakan login.", Toast.LENGTH_LONG).show();
                        startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                        finish();
                    } else {
                        showError(response.body().message);
                    }
                } else {
                    showError("Gagal mendaftar, coba lagi");
                }
            }
            @Override
            public void onFailure(Call<BaseResponse<Object>> call, Throwable t) {
                setLoading(false);
                showError("Tidak dapat terhubung ke server");
            }
        });
    }

    private void showError(String msg) {
        tvError.setText(msg);
        layoutError.setVisibility(View.VISIBLE);
    }

    private void setLoading(boolean l) {
        progressBar.setVisibility(l ? View.VISIBLE : View.GONE);
        btnRegister.setEnabled(!l);
        btnRegister.setText(l ? "Mendaftarkan..." : "Daftar Sekarang");
        layoutError.setVisibility(View.GONE);
    }
}
