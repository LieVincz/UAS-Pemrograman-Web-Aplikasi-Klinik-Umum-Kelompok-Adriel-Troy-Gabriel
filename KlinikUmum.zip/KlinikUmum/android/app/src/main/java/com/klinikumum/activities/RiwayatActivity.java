package com.klinikumum.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.klinikumum.R;
import com.klinikumum.adapters.RiwayatAdapter;
import com.klinikumum.models.*;
import com.klinikumum.network.ApiClient;
import com.klinikumum.utils.SessionManager;
import java.util.*;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RiwayatActivity extends AppCompatActivity {

    private SessionManager session;
    private RecyclerView rvRiwayat;
    private ProgressBar progressBar;
    private SwipeRefreshLayout swipeRefresh;
    private TextView tvEmpty;
    private RiwayatAdapter adapter;
    private final List<RiwayatMedis> list = new ArrayList<>();
    private boolean modeSelection = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_riwayat);

        modeSelection = getIntent().getBooleanExtra("mode_selection", false);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(modeSelection ? "Pilih Rekam Medis" : "Riwayat Rekam Medis");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        session      = new SessionManager(this);
        rvRiwayat    = findViewById(R.id.rvRiwayat);
        progressBar  = findViewById(R.id.progressBar);
        swipeRefresh = findViewById(R.id.swipeRefresh);
        tvEmpty      = findViewById(R.id.tvEmpty);

        if (modeSelection) {
            adapter = new RiwayatAdapter(list, item -> {
                Log.d("RiwayatActivity", "Item clicked: ID=" + item.getSafeId() + " No=" + item.noAntrian);
                Intent intent = new Intent(this, DetailPendaftaranActivity.class);
                intent.putExtra("riwayat_medis", item);
                startActivity(intent);
            });
        } else {
            adapter = new RiwayatAdapter(list);
        }
        rvRiwayat.setLayoutManager(new LinearLayoutManager(this));
        rvRiwayat.setAdapter(adapter);

        swipeRefresh.setOnRefreshListener(this::loadData);
        loadData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }

    private void loadData() {
        if (!swipeRefresh.isRefreshing()) {
            progressBar.setVisibility(View.VISIBLE);
        }
        tvEmpty.setVisibility(View.GONE);

        String token = "Bearer " + session.getToken();

        // Gunakan getPendaftaranList — endpoint ini sudah pasti bekerja untuk pasien,
        // mengembalikan SEMUA antrian tanpa filter status, dengan nama_dokter dan spesialisasi.
        ApiClient.getService().getPendaftaranList(token, null)
                .enqueue(new Callback<BaseResponse<List<Pendaftaran>>>() {
                    @Override
                    public void onResponse(Call<BaseResponse<List<Pendaftaran>>> call,
                                           Response<BaseResponse<List<Pendaftaran>>> response) {
                        progressBar.setVisibility(View.GONE);
                        swipeRefresh.setRefreshing(false);
                        list.clear();

                        try {
                            if (response != null && response.isSuccessful()
                                    && response.body() != null && response.body().status
                                    && response.body().data != null) {

                                for (Pendaftaran p : response.body().data) {
                                    list.add(convertToRiwayat(p));
                                }
                            } else {
                                String msg = (response != null && response.body() != null)
                                        ? response.body().message : "Gagal memuat data";
                                Log.e("RiwayatActivity", "Response error: " + msg);
                            }
                        } catch (Exception e) {
                            Log.e("RiwayatActivity", "Parse error: " + e.getMessage(), e);
                        }

                        adapter.notifyDataSetChanged();
                        if (list.isEmpty()) {
                            tvEmpty.setText("Belum ada riwayat rekam medis");
                            tvEmpty.setVisibility(View.VISIBLE);
                        } else {
                            tvEmpty.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onFailure(Call<BaseResponse<List<Pendaftaran>>> call, Throwable t) {
                        progressBar.setVisibility(View.GONE);
                        swipeRefresh.setRefreshing(false);
                        Log.e("RiwayatActivity", "onFailure: " + t.getMessage(), t);
                        if (list.isEmpty()) tvEmpty.setVisibility(View.VISIBLE);
                        Toast.makeText(RiwayatActivity.this,
                                "Koneksi gagal: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private RiwayatMedis convertToRiwayat(Pendaftaran p) {
        RiwayatMedis r = new RiwayatMedis();
        r.pendaftaranId = p.id;
        r.noAntrian     = p.noAntrian;
        r.tanggal       = p.tanggal;
        r.keluhan       = p.keluhan;
        r.status        = p.status;
        r.namaPasien    = p.getNamaDisplay();
        r.namaDokter    = p.namaDokter;
        r.spesialisasi  = p.spesialisasi;
        r.diagnosa      = p.diagnosa;
        r.catatan       = p.catatan;
        r.tekananDarah  = p.tekananDarah;
        r.suhu          = p.suhu;
        r.beratBadan    = p.beratBadan;
        r.tinggiBadan   = p.tinggiBadan;
        r.total         = p.total;
        r.statusBayar   = p.statusBayar;
        r.noInvoice     = p.noInvoice;
        r.resep         = p.resep;
        return r;
    }
}
