package com.klinikumum.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import com.klinikumum.R;
import com.klinikumum.utils.SessionManager;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(() -> {
            SessionManager session = new SessionManager(this);
            Intent intent;
            if (session.isLoggedIn()) {
                intent = getIntentByRole(session.getRole());
            } else {
                intent = new Intent(this, LoginActivity.class);
            }
            startActivity(intent);
            finish();
        }, 2000);
    }

    private Intent getIntentByRole(String role) {
        switch (role) {
            case "admin":  return new Intent(this, AdminMainActivity.class);
            case "dokter": return new Intent(this, DokterMainActivity.class);
            default:       return new Intent(this, PasienMainActivity.class);
        }
    }
}
