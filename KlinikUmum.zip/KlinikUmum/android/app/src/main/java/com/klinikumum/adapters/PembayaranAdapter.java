package com.klinikumum.adapters;

import android.graphics.Color;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.klinikumum.R;
import com.klinikumum.models.Pembayaran;
import java.util.List;

public class PembayaranAdapter extends RecyclerView.Adapter<PembayaranAdapter.ViewHolder> {

    public interface OnKonfirmasiClick { void onClick(Pembayaran item); }

    private final List<Pembayaran> list;
    private final OnKonfirmasiClick listener;

    public PembayaranAdapter(List<Pembayaran> list, OnKonfirmasiClick listener) {
        this.list = list;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_pembayaran, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        Pembayaran p = list.get(position);
        h.tvNamaPasien.setText(p.namaPasien != null ? p.namaPasien : "-");
        h.tvNoInvoice.setText(p.noInvoice != null ? p.noInvoice : "-");
        h.tvTotal.setText("Rp " + String.format("%,.0f", p.total));
        h.tvStatus.setText(p.getStatusLabel());
        h.tvJenis.setText(p.jenisPembayaran != null ? p.jenisPembayaran.toUpperCase() : "-");

        boolean belumBayar = "belum_bayar".equals(p.status);
        h.btnKonfirmasi.setVisibility(belumBayar ? View.VISIBLE : View.GONE);
        h.btnKonfirmasi.setOnClickListener(v -> listener.onClick(p));

        int statusColor = belumBayar ? Color.parseColor("#FF6D00") :
                ("sudah_bayar".equals(p.status) ? Color.parseColor("#2E7D32") : Color.parseColor("#1565C0"));
        h.tvStatus.setTextColor(statusColor);
    }

    @Override public int getItemCount() { return list.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNamaPasien, tvNoInvoice, tvTotal, tvStatus, tvJenis;
        MaterialButton btnKonfirmasi;
        ViewHolder(@NonNull View v) {
            super(v);
            tvNamaPasien = v.findViewById(R.id.tvNamaPasien);
            tvNoInvoice  = v.findViewById(R.id.tvNoInvoice);
            tvTotal      = v.findViewById(R.id.tvTotal);
            tvStatus     = v.findViewById(R.id.tvStatus);
            tvJenis      = v.findViewById(R.id.tvJenis);
            btnKonfirmasi= v.findViewById(R.id.btnKonfirmasi);
        }
    }
}
