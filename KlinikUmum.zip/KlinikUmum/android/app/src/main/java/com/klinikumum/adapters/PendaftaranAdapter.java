package com.klinikumum.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.klinikumum.R;
import com.klinikumum.models.Pendaftaran;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class PendaftaranAdapter extends RecyclerView.Adapter<PendaftaranAdapter.ViewHolder> {

    private final List<Pendaftaran> list;
    private final OnItemClickListener listener;
    private OnActionClick actionListener;

    public interface OnItemClickListener {
        void onItemClick(Pendaftaran item);
    }

    public interface OnActionClick {
        void onPanggil(Pendaftaran item);
        void onBatal(Pendaftaran item);
    }

    public PendaftaranAdapter(List<Pendaftaran> list, OnItemClickListener listener) {
        this.list = list;
        this.listener = listener;
    }

    public PendaftaranAdapter(List<Pendaftaran> list, OnItemClickListener listener, OnActionClick actionListener) {
        this.list = list;
        this.listener = listener;
        this.actionListener = actionListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_pendaftaran, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Pendaftaran item = list.get(position);
        holder.bind(item, listener, actionListener);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNoAntrian, tvNama, tvKeluhan, tvDokter, tvStatus, tvTanggal;
        TextView tvWaktuDaftar, tvWaktuBerlaku;
        LinearLayout layoutAksi, layoutWaktu;
        Button btnPanggil, btnBatal;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNoAntrian = itemView.findViewById(R.id.tvNoAntrian);
            tvNama = itemView.findViewById(R.id.tvNama);
            tvKeluhan = itemView.findViewById(R.id.tvKeluhan);
            tvDokter = itemView.findViewById(R.id.tvDokter);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvTanggal = itemView.findViewById(R.id.tvTanggal);
            tvWaktuDaftar  = itemView.findViewById(R.id.tvWaktuDaftar);
            tvWaktuBerlaku = itemView.findViewById(R.id.tvWaktuBerlaku);
            layoutAksi  = itemView.findViewById(R.id.layoutAksi);
            layoutWaktu = itemView.findViewById(R.id.layoutWaktu);
            btnPanggil = itemView.findViewById(R.id.btnPanggil);
            btnBatal = itemView.findViewById(R.id.btnBatal);
        }

        void bind(final Pendaftaran item, final OnItemClickListener listener, final OnActionClick actionListener) {
            tvNoAntrian.setText(item.noAntrian);
            tvNama.setText(item.getNamaDisplay());
            tvKeluhan.setText(item.keluhan);
            tvDokter.setText(item.namaDokter != null ? "Dr. " + item.namaDokter : "-");
            tvTanggal.setText(item.tanggal);

            // Waktu daftar & waktu berlaku
            SimpleDateFormat sdfOut = new SimpleDateFormat("HH:mm", Locale.getDefault());
            String timeSource = (item.waktuDaftar != null && !item.waktuDaftar.isEmpty()) ? item.waktuDaftar : item.createdAt;

            if (timeSource != null && !timeSource.isEmpty()) {
                layoutWaktu.setVisibility(View.VISIBLE);
                try {
                    SimpleDateFormat sdfParser = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                    Date tDaftar = sdfParser.parse(timeSource);

                    Calendar now = Calendar.getInstance();
                    Calendar dCal = Calendar.getInstance();
                    dCal.setTime(tDaftar);

                    // Penyesuaian offset waktu server (asumsi server UTC)
                    if (now.get(Calendar.HOUR_OF_DAY) >= 5 && (now.get(Calendar.HOUR_OF_DAY) - dCal.get(Calendar.HOUR_OF_DAY)) >= 4) {
                         dCal.add(Calendar.HOUR_OF_DAY, 5);
                         tDaftar = dCal.getTime();
                    }
                    
                    Date tBerlaku;
                    if (item.waktuBerlaku != null && !item.waktuBerlaku.isEmpty()) {
                        tBerlaku = sdfParser.parse(item.waktuBerlaku);
                        Calendar bCal = Calendar.getInstance();
                        bCal.setTime(tBerlaku);
                        if (now.get(Calendar.HOUR_OF_DAY) >= 5 && (now.get(Calendar.HOUR_OF_DAY) - (bCal.get(Calendar.HOUR_OF_DAY) - 1)) >= 4) {
                            bCal.add(Calendar.HOUR_OF_DAY, 5);
                            tBerlaku = bCal.getTime();
                        }
                    } else {
                        Calendar cal = Calendar.getInstance();
                        cal.setTime(tDaftar);
                        cal.add(Calendar.HOUR_OF_DAY, 1);
                        tBerlaku = cal.getTime();
                    }

                    tvWaktuDaftar.setText("⏰ Daftar: " + sdfOut.format(tDaftar));
                    
                    // Tampilkan info kedaluwarsa jika sudah lewat waktu, kecuali jika sudah selesai/batal
                    boolean isPending = "menunggu".equals(item.status) || "dipanggil".equals(item.status);
                    if (isPending && new Date().after(tBerlaku)) {
                        tvWaktuBerlaku.setText("⚠ KEDALUWARSA: " + sdfOut.format(tBerlaku));
                        tvWaktuBerlaku.setTextColor(Color.parseColor("#C62828"));
                    } else {
                        tvWaktuBerlaku.setText("⌛ Berlaku s/d: " + sdfOut.format(tBerlaku));
                        tvWaktuBerlaku.setTextColor(Color.parseColor("#546E7A"));
                    }
                } catch (ParseException e) {
                    layoutWaktu.setVisibility(View.GONE);
                }
            } else {
                layoutWaktu.setVisibility(View.GONE);
            }

            // Status Badge
            tvStatus.setText(item.getStatusLabel());
            int[] colors = getStatusColor(item.status);
            tvStatus.getBackground().setTint(colors[0]);
            tvStatus.setTextColor(colors[1]);

            itemView.setOnClickListener(v -> listener.onItemClick(item));

            // Tombol Aksi Admin
            if (actionListener != null) {
                layoutAksi.setVisibility(View.VISIBLE);
                btnPanggil.setVisibility(View.VISIBLE);
                btnBatal.setVisibility(View.VISIBLE);

                if ("dipanggil".equals(item.status)) {
                    btnPanggil.setText("📢 Panggil Ulang");
                } else if ("selesai".equals(item.status)) {
                    btnPanggil.setText("📢 Panggil Lagi");
                } else {
                    btnPanggil.setText("📢 Panggil");
                }

                btnPanggil.setOnClickListener(v -> actionListener.onPanggil(item));
                btnBatal.setOnClickListener(v -> actionListener.onBatal(item));
            } else {
                layoutAksi.setVisibility(View.GONE);
            }
        }

        private int[] getStatusColor(String status) {
            if (status == null) return new int[]{Color.GRAY, Color.WHITE};
            switch (status) {
                case "menunggu":  return new int[]{Color.parseColor("#E65100"), Color.WHITE};
                case "dipanggil": return new int[]{Color.parseColor("#1565C0"), Color.WHITE};
                case "selesai":   return new int[]{Color.parseColor("#2E7D32"), Color.WHITE};
                case "batal":     return new int[]{Color.parseColor("#C62828"), Color.WHITE};
                default:          return new int[]{Color.GRAY, Color.WHITE};
            }
        }
    }
}
