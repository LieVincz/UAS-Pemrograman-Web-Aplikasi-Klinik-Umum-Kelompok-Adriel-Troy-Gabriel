package com.klinikumum.adapters;

import android.graphics.Color;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.klinikumum.R;
import com.klinikumum.models.RiwayatMedis;
import java.util.List;
import java.util.Locale;

public class RiwayatAdapter extends RecyclerView.Adapter<RiwayatAdapter.ViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(RiwayatMedis item);
    }

    private final List<RiwayatMedis> list;
    private final OnItemClickListener listener;

    public RiwayatAdapter(List<RiwayatMedis> list) {
        this(list, null);
    }

    public RiwayatAdapter(List<RiwayatMedis> list, OnItemClickListener listener) {
        this.list = list;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_riwayat, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        RiwayatMedis r = list.get(position);

        h.tvTanggal.setText(r.tanggal != null ? r.tanggal : "-");

        if (r.namaPasien != null && !r.namaPasien.isEmpty()) {
            h.tvDokter.setText("Pasien: " + r.namaPasien + "\nDr. " + (r.namaDokter != null ? r.namaDokter : "-"));
        } else {
            h.tvDokter.setText(r.namaDokter != null ? "Dr. " + r.namaDokter : "-");
        }

        h.tvNoAntrian.setText(r.noAntrian != null ? r.noAntrian : "-");

        // Status badge — teks + warna latar
        String statusLabel = getStatusLabel(r.status);
        h.tvStatus.setText(statusLabel);
        int[] colors = getStatusColor(r.status);
        h.tvStatus.getBackground().setTint(colors[0]);
        h.tvStatus.setTextColor(colors[1]);

        if (listener != null) {
            h.itemView.setOnClickListener(v -> listener.onItemClick(r));
            h.itemView.setClickable(true);
            h.itemView.setFocusable(true);
            // Ripple effect
            android.util.TypedValue outValue = new android.util.TypedValue();
            h.itemView.getContext().getTheme().resolveAttribute(android.R.attr.selectableItemBackground, outValue, true);
            h.itemView.setForeground(h.itemView.getContext().getDrawable(outValue.resourceId));
        } else {
            h.itemView.setOnClickListener(null);
            h.itemView.setClickable(false);
            h.itemView.setFocusable(false);
            h.itemView.setForeground(null);
        }
    }

    private String getStatusLabel(String status) {
        if (status == null) return "-";
        switch (status) {
            case "menunggu":  return "Menunggu";
            case "dipanggil": return "Dipanggil";
            case "selesai":   return "Selesai";
            case "batal":     return "Batal";
            default:          return status;
        }
    }

    /** Returns {backgroundColor, textColor} */
    private int[] getStatusColor(String status) {
        if (status == null) return new int[]{Color.GRAY, Color.WHITE};
        switch (status) {
            case "menunggu":  return new int[]{Color.parseColor("#E65100"), Color.WHITE};
            case "dipanggil": return new int[]{Color.parseColor("#1565C0"), Color.WHITE};
            case "selesai":   return new int[]{Color.parseColor("#2E7D32"), Color.WHITE};
            case "batal":     return new int[]{Color.parseColor("#C62828"), Color.WHITE};
            default:          return new int[]{Color.GRAY, Color.WHITE};
        }
    }

    @Override public int getItemCount() { return list.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTanggal, tvDokter, tvNoAntrian, tvStatus;

        ViewHolder(@NonNull View v) {
            super(v);
            tvTanggal    = v.findViewById(R.id.tvTanggal);
            tvDokter     = v.findViewById(R.id.tvDokter);
            tvNoAntrian  = v.findViewById(R.id.tvNoAntrian);
            tvStatus     = v.findViewById(R.id.tvStatus);
        }
    }
}
