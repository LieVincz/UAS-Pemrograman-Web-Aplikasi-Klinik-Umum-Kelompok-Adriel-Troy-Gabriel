package com.klinikumum.models;
import com.google.gson.annotations.SerializedName;
import java.util.List;

public class DashboardData {
    // Admin & Dokter
    @SerializedName("pasien_hari_ini")   public int pasienHariIni;
    @SerializedName("antrian_menunggu")  public int antrianMenunggu;
    @SerializedName("pendapatan_hari_ini") public double pendapatanHariIni;
    @SerializedName("antrian_list")      public List<Pendaftaran> antrianList;

    // Pasien
    @SerializedName("total_kunjungan")   public int totalKunjungan;
    @SerializedName("antrian_aktif")     public Pendaftaran antrianAktif;
    @SerializedName("tagihan_pending")   public Pembayaran tagihanPending;
}
