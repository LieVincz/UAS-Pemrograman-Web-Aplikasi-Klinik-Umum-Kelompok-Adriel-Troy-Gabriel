package com.klinikumum.models;
import com.google.gson.annotations.SerializedName;

public class Dokter {
    @SerializedName("id")           public String id;
    @SerializedName("nama")         public String nama;
    @SerializedName("spesialisasi") public String spesialisasi;
    @SerializedName("jadwal")       public String jadwal;

    @Override
    public String toString() { return "Dr. " + nama + " (" + spesialisasi + ")"; }
}
