package com.klinikumum.models;

import com.google.gson.annotations.SerializedName;

public class LoginData {
    @SerializedName("token")
    public String token;

    @SerializedName("user")
    public UserProfil user;
}
