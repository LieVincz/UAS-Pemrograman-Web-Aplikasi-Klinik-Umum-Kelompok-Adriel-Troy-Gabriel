package com.klinikumum.models;
import com.google.gson.annotations.SerializedName;

public class Pembayaran {
    @SerializedName("id")               public int id;
    @SerializedName("pendaftaran_id")   public int pendaftaranId;
    @SerializedName("no_invoice")       public String noInvoice;
    @SerializedName("biaya_konsultasi") public double biayaKonsultasi;
    @SerializedName("biaya_obat")       public double biayaObat;
    @SerializedName("biaya_admin")      public double biayaAdmin;
    @SerializedName("total")            public double total;
    @SerializedName("jenis_pembayaran") public String jenisPembayaran;
    @SerializedName("status")          public String status;
    @SerializedName("tanggal_bayar")   public String tanggalBayar;
    @SerializedName("created_at")      public String createdAt;
    @SerializedName("nama_pasien")     public String namaPasien;
    @SerializedName("no_rm")           public String noRm;
    @SerializedName("no_antrian")      public String noAntrian;
    @SerializedName("tanggal")         public String tanggal;

    public String getStatusLabel() {
        if (status == null) return "-";
        switch (status) {
            case "belum_bayar": return "Belum Bayar";
            case "sudah_bayar": return "Lunas";
            case "ditanggung":  return "Ditanggung";
            default: return status;
        }
    }
}
