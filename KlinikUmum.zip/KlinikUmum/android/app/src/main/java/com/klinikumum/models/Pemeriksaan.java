package com.klinikumum.models;
import com.google.gson.annotations.SerializedName;
import java.util.List;

public class Pemeriksaan {
    @SerializedName("id")             public int id;
    @SerializedName("pendaftaran_id") public int pendaftaranId;
    @SerializedName("dokter_id")      public int dokterId;
    @SerializedName("tekanan_darah")  public String tekananDarah;
    @SerializedName("suhu")           public Float suhu;        // Float (wrapper), bukan float primitive
    @SerializedName("berat_badan")    public Float beratBadan;  // Float (wrapper), bukan float primitive
    @SerializedName("tinggi_badan")   public Float tinggiBadan; // Float (wrapper), bukan float primitive
    @SerializedName("diagnosa")       public String diagnosa;
    @SerializedName("catatan")        public String catatan;
    @SerializedName("status")         public String status;
    @SerializedName("resep")          public List<Resep> resep;
}
