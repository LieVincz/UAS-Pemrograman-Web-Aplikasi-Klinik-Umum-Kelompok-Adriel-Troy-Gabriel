package com.klinikumum.models;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.List;

public class Pendaftaran implements Serializable {
    @SerializedName("id")               public Integer id;
    @SerializedName("no_antrian")       public String noAntrian;
    @SerializedName("pasien_id")        public int pasienId;
    @SerializedName("dokter_id")        public int dokterId;
    @SerializedName("tanggal")          public String tanggal;
    @SerializedName("keluhan")          public String keluhan;
    @SerializedName("status")           public String status;
    @SerializedName("jenis_pembayaran") public String jenisPembayaran;
    @SerializedName("no_bpjs")          public String noBpjs;
    @SerializedName("no_asuransi")      public String noAsuransi;
    @SerializedName("created_at")       public String createdAt;
    @SerializedName("waktu_daftar")     public String waktuDaftar;
    @SerializedName("waktu_berlaku")    public String waktuBerlaku;

    @SerializedName("nama_pasien")   public String namaPasien;
    @SerializedName("no_rm")         public String noRm;
    @SerializedName("nama_dokter")   public String namaDokter;
    @SerializedName("spesialisasi")  public String spesialisasi;

    @SerializedName("pemeriksaan_id")   public int pemeriksaanId;
    @SerializedName("tekanan_darah")    public String tekananDarah;
    @SerializedName("suhu")            public Float suhu;
    @SerializedName("berat_badan")     public Float beratBadan;
    @SerializedName("tinggi_badan")    public Float tinggiBadan;
    @SerializedName("diagnosa")        public String diagnosa;
    @SerializedName("catatan")         public String catatan;
    @SerializedName("status_periksa")  public String statusPeriksa;

    @SerializedName("pembayaran_id")   public int pembayaranId;
    @SerializedName("no_invoice")      public String noInvoice;
    @SerializedName("total")           public Double total;
    @SerializedName("status_bayar")    public String statusBayar;
    @SerializedName("biaya_konsultasi") public double biayaKonsultasi;
    @SerializedName("biaya_obat")      public double biayaObat;
    @SerializedName("biaya_admin")     public double biayaAdmin;

    @SerializedName("resep") public List<Resep> resep;

    @SerializedName("untuk_diri_sendiri")  public int untukDiriSendiri;
    @SerializedName("nama_pasien_lain")    public String namaPasienLain;
    @SerializedName("hubungan")            public String hubungan;
    @SerializedName("no_hp_pasien_lain")   public String noHpPasienLain;

    public String getNamaDisplay() {
        if (untukDiriSendiri == 1 || namaPasienLain == null || namaPasienLain.isEmpty()) {
            return namaPasien != null ? namaPasien : "-";
        }
        return namaPasienLain + " (" + (hubungan != null ? hubungan : "Keluarga") + ")";
    }

    public String getStatusLabel() {
        if (status == null) return "-";
        switch (status) {
            case "menunggu":  return "Menunggu";
            case "dipanggil": return "Dipanggil";
            case "selesai":   return "Selesai";
            case "batal":     return "Batal";
            default: return status;
        }
    }
}
