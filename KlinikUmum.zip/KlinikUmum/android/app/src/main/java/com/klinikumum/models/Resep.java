package com.klinikumum.models;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class Resep implements Serializable {
    @SerializedName("id")              public int id;
    @SerializedName("pemeriksaan_id")  public int pemeriksaanId;
    @SerializedName("nama_obat")       public String namaObat;
    @SerializedName("dosis")           public String dosis;
    @SerializedName("aturan_pakai")    public String aturanPakai;
    @SerializedName("jumlah")          public int jumlah;
    @SerializedName("keterangan")      public String keterangan;
}
