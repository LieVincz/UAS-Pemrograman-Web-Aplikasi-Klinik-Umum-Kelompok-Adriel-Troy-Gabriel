package com.klinikumum.models;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.List;

public class RiwayatMedis implements Serializable {
    @SerializedName("pendaftaran_id") public Integer pendaftaranId;
    @SerializedName("id")             public Integer id; // Tambahan jika API pakai 'id'
    
    public int getSafeId() {
        if (pendaftaranId != null && pendaftaranId > 0) return pendaftaranId;
        if (id != null && id > 0) return id;
        return 0;
    }

    @SerializedName("no_antrian")     public String noAntrian;
    @SerializedName("tanggal")        public String tanggal;
    @SerializedName("keluhan")        public String keluhan;
    @SerializedName("status")         public String status;
    @SerializedName("nama_pasien")    public String namaPasien;
    @SerializedName("nama_dokter")    public String namaDokter;
    @SerializedName("spesialisasi")   public String spesialisasi;
    @SerializedName("diagnosa")       public String diagnosa;
    @SerializedName("catatan")        public String catatan;
    @SerializedName("tekanan_darah")  public String tekananDarah;
    @SerializedName("suhu")           public Float suhu;
    @SerializedName("berat_badan")    public Float beratBadan;
    @SerializedName("tinggi_badan")   public Float tinggiBadan;
    @SerializedName("total")          public Double total;
    @SerializedName("status_bayar")   public String statusBayar;
    @SerializedName("no_invoice")     public String noInvoice;
    @SerializedName("resep")          public List<Resep> resep;
}
