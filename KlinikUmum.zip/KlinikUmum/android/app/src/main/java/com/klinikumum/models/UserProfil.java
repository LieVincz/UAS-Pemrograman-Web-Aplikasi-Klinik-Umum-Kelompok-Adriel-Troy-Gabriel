package com.klinikumum.models;

import com.google.gson.annotations.SerializedName;

public class UserProfil {
    @SerializedName("id")         public int id;
    @SerializedName("nama")       public String nama;
    @SerializedName("email")      public String email;
    @SerializedName("role")       public String role;
    @SerializedName("no_telepon") public String noTelepon;
    @SerializedName("alamat")     public String alamat;

    // Pasien fields
    @SerializedName("pasien_id")      public int pasienId;
    @SerializedName("no_rm")          public String noRm;
    @SerializedName("tanggal_lahir")  public String tanggalLahir;
    @SerializedName("jenis_kelamin")  public String jenisKelamin;
    @SerializedName("golongan_darah") public String golonganDarah;
    @SerializedName("alergi")         public String alergi;

    // Dokter fields
    @SerializedName("dokter_id")   public int dokterId;
    @SerializedName("spesialisasi") public String spesialisasi;
}
