package com.klinikumum.network;

import com.klinikumum.models.*;
import java.util.List;
import java.util.Map;
import retrofit2.Call;
import retrofit2.http.*;

public interface ApiService {

    // ==================== AUTH ====================
    @POST("auth.php?action=login")
    Call<BaseResponse<LoginData>> login(@Body Map<String, String> body);

    @POST("auth.php?action=register")
    Call<BaseResponse<Object>> register(@Body Map<String, String> body);

    // ==================== PENDAFTARAN ====================
    @GET("pendaftaran.php?action=list")
    Call<BaseResponse<List<Pendaftaran>>> getPendaftaranList(
            @Header("Authorization") String token,
            @Query("tanggal") String tanggal
    );

    @GET("pendaftaran.php?action=detail")
    Call<BaseResponse<Pendaftaran>> getDetailPendaftaran(
            @Header("Authorization") String token,
            @Query("pendaftaran_id") int id
    );

    @POST("pendaftaran.php?action=daftar")
    Call<BaseResponse<Object>> daftarAntrian(
            @Header("Authorization") String token,
            @Body Map<String, Object> body
    );

    @POST("pendaftaran.php?action=update")
    Call<BaseResponse<Object>> updateStatusPendaftaran(
            @Header("Authorization") String token,
            @Body Map<String, Object> body
    );

    @POST("pendaftaran.php?action=delete")
    Call<BaseResponse<Object>> deletePendaftaran(
            @Header("Authorization") String token,
            @Body Map<String, Object> body
    );

    @GET("pendaftaran.php?action=dokter")
    Call<BaseResponse<List<Dokter>>> getDokterList(
            @Header("Authorization") String token
    );

    // ==================== PEMERIKSAAN ====================
    @POST("pemeriksaan.php?action=simpan")
    Call<BaseResponse<Object>> simpanPemeriksaan(
            @Header("Authorization") String token,
            @Body Map<String, Object> body
    );

    @POST("pemeriksaan.php?action=update")
    Call<BaseResponse<Object>> updatePemeriksaan(
            @Header("Authorization") String token,
            @Body Map<String, Object> body
    );

    @GET("pemeriksaan.php?action=get")
    Call<BaseResponse<Pemeriksaan>> getPemeriksaan(
            @Header("Authorization") String token,
            @Query("pendaftaran_id") int pendaftaranId
    );

    @POST("pemeriksaan.php?action=tambah_resep")
    Call<BaseResponse<Object>> tambahResep(
            @Header("Authorization") String token,
            @Body Map<String, Object> body
    );

    @POST("pemeriksaan.php?action=hapus_resep")
    Call<BaseResponse<Object>> hapusResep(
            @Header("Authorization") String token,
            @Body Map<String, Object> body
    );

    // ==================== PEMBAYARAN ====================
    @POST("pembayaran.php?action=buat")
    Call<BaseResponse<Object>> buatPembayaran(
            @Header("Authorization") String token,
            @Body Map<String, Object> body
    );

    @POST("pembayaran.php?action=bayar")
    Call<BaseResponse<Object>> konfirmasiPembayaran(
            @Header("Authorization") String token,
            @Body Map<String, Object> body
    );

    @GET("pembayaran.php?action=detail")
    Call<BaseResponse<Pembayaran>> getDetailPembayaran(
            @Header("Authorization") String token,
            @Query("pendaftaran_id") int pendaftaranId
    );

    @GET("pembayaran.php?action=list")
    Call<BaseResponse<List<Pembayaran>>> getListPembayaran(
            @Header("Authorization") String token
    );

    // ==================== REKAM MEDIS / DASHBOARD ====================
    @GET("rekam_medis.php?action=riwayat")
    Call<BaseResponse<List<RiwayatMedis>>> getRiwayat(
            @Header("Authorization") String token
    );

    @GET("rekam_medis.php?action=dashboard")
    Call<BaseResponse<DashboardData>> getDashboard(
            @Header("Authorization") String token
    );

    @GET("rekam_medis.php?action=profil")
    Call<BaseResponse<UserProfil>> getProfil(
            @Header("Authorization") String token
    );

    @POST("rekam_medis.php?action=edit_profil")
    Call<BaseResponse<Object>> editProfil(
            @Header("Authorization") String token,
            @Body Map<String, String> body
    );
}
