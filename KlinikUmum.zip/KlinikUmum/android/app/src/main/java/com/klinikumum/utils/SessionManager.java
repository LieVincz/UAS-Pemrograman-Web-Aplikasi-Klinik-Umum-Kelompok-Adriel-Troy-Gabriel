package com.klinikumum.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    private static final String PREF_NAME = "KlinikSession";
    private static final String KEY_TOKEN = "token";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_NAMA = "nama";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_ROLE = "role";
    private static final String KEY_PASIEN_ID = "pasien_id";
    private static final String KEY_DOKTER_ID = "dokter_id";
    private static final String KEY_NO_RM = "no_rm";

    private final SharedPreferences pref;
    private final SharedPreferences.Editor editor;

    public SessionManager(Context context) {
        pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = pref.edit();
    }

    public void saveSession(String token, int userId, String nama, String email,
                            String role, int pasienId, int dokterId, String noRm) {
        editor.putString(KEY_TOKEN, token);
        editor.putInt(KEY_USER_ID, userId);
        editor.putString(KEY_NAMA, nama);
        editor.putString(KEY_EMAIL, email);
        editor.putString(KEY_ROLE, role);
        editor.putInt(KEY_PASIEN_ID, pasienId);
        editor.putInt(KEY_DOKTER_ID, dokterId);
        editor.putString(KEY_NO_RM, noRm);
        editor.apply();
    }

    public boolean isLoggedIn() {
        return pref.getString(KEY_TOKEN, null) != null;
    }

    public String getToken()    { return pref.getString(KEY_TOKEN, ""); }
    public int    getUserId()   { return pref.getInt(KEY_USER_ID, 0); }
    public String getNama()     { return pref.getString(KEY_NAMA, ""); }
    public String getEmail()    { return pref.getString(KEY_EMAIL, ""); }
    public String getRole()     { return pref.getString(KEY_ROLE, ""); }
    public int    getPasienId() { return pref.getInt(KEY_PASIEN_ID, 0); }
    public int    getDokterId() { return pref.getInt(KEY_DOKTER_ID, 0); }
    public String getNoRm()     { return pref.getString(KEY_NO_RM, ""); }

    public boolean isAdmin()  { return "admin".equals(getRole()); }
    public boolean isDokter() { return "dokter".equals(getRole()); }
    public boolean isPasien() { return "pasien".equals(getRole()); }

    public void logout() {
        editor.clear();
        editor.apply();
    }
}
