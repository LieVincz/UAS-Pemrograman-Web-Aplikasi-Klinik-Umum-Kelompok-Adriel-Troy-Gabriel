<?php
require_once 'config.php';

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'login':    doLogin();    break;
    case 'register': doRegister(); break;
    default: respond(false, 'Action tidak valid');
}


function doLogin() {
    requireMethod('POST');
    $body = getBody();
    $email    = trim($body['email'] ?? '');
    $password = trim($body['password'] ?? '');

    if (empty($email) || empty($password)) {
        respond(false, 'Email dan password wajib diisi');
    }

    $db = getDB();
    $hashedPass = md5($password);
    $stmt = $db->prepare("SELECT u.*, p.id as pasien_id, p.no_rm, p.tanggal_lahir, p.jenis_kelamin, p.golongan_darah, p.alergi,
                                 d.id as dokter_id, d.spesialisasi, d.jadwal
                          FROM users u 
                          LEFT JOIN pasien p ON p.user_id = u.id 
                          LEFT JOIN dokter d ON d.user_id = u.id
                          WHERE u.email = ? AND u.password = ? LIMIT 1");
    $stmt->bind_param("ss", $email, $hashedPass);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $db->close();

    if (!$user) {
        respond(false, 'Email atau password salah');
    }


    $token = base64_encode($user['id'] . ':' . time());

    unset($user['password']);
    respond(true, 'Login berhasil', [
        'token' => $token,
        'user'  => $user
    ]);
}


function doRegister() {
    requireMethod('POST');
    $body = getBody();

    $nama          = trim($body['nama'] ?? '');
    $email         = trim($body['email'] ?? '');
    $password      = trim($body['password'] ?? '');
    $no_telepon    = trim($body['no_telepon'] ?? '');
    $tanggal_lahir = trim($body['tanggal_lahir'] ?? '');
    $jenis_kelamin = trim($body['jenis_kelamin'] ?? 'L');

    if (empty($nama) || empty($email) || empty($password)) {
        respond(false, 'Nama, email, dan password wajib diisi');
    }

    $db = getDB();


    $cek = $db->prepare("SELECT id FROM users WHERE email = ?");
    $cek->bind_param("s", $email);
    $cek->execute();
    if ($cek->get_result()->num_rows > 0) {
        $db->close();
        respond(false, 'Email sudah terdaftar');
    }

    $hashedPass = md5($password);


    $stmt = $db->prepare("INSERT INTO users (nama, email, password, role, no_telepon) VALUES (?,?,?,'pasien',?)");
    $stmt->bind_param("ssss", $nama, $email, $hashedPass, $no_telepon);
    $stmt->execute();
    $userId = $stmt->insert_id;


    $count = $db->query("SELECT COUNT(*) as c FROM pasien")->fetch_assoc()['c'];
    $no_rm = 'RM-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT);


    $stmt2 = $db->prepare("INSERT INTO pasien (user_id, no_rm, tanggal_lahir, jenis_kelamin) VALUES (?,?,?,?)");
    $stmt2->bind_param("isss", $userId, $no_rm, $tanggal_lahir, $jenis_kelamin);
    $stmt2->execute();

    $db->close();
    respond(true, 'Registrasi berhasil! Silahkan login.', ['no_rm' => $no_rm]);
}
