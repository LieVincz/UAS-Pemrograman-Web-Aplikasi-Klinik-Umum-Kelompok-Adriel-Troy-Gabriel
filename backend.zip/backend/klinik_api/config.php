<?php



ini_set('display_errors', 0);
error_reporting(E_ALL); 

date_default_timezone_set('Asia/Jakarta');


mysqli_report(MYSQLI_REPORT_OFF);

define('DB_HOST', 'localhost');
define('DB_USER', 'root');       
define('DB_PASS', '');           
define('DB_NAME', 'klinik_umum');


header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

function getDB() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        http_response_code(500);
        echo json_encode(['status' => false, 'message' => 'Koneksi DB gagal: ' . $conn->connect_error]);
        exit();
    }
    $conn->set_charset("utf8mb4");
    return $conn;
}

function respond($status, $message, $data = null) {
    $response = ['status' => $status, 'message' => $message];
    if ($data !== null) $response['data'] = $data;
    echo json_encode($response);
    exit();
}

function getBody() {
    return json_decode(file_get_contents('php://input'), true) ?? [];
}

function requireMethod($method) {
    if ($_SERVER['REQUEST_METHOD'] !== strtoupper($method)) {
        respond(false, 'Method tidak diizinkan');
    }
}

function getAuth() {
    $headers = getallheaders();
    $token = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    $token = str_replace('Bearer ', '', $token);
    if (empty($token)) return null;

    $db = getDB();
    $stmt = $db->prepare("SELECT u.*, p.id as pasien_id, p.no_rm, d.id as dokter_id FROM users u 
                          LEFT JOIN pasien p ON p.user_id = u.id 
                          LEFT JOIN dokter d ON d.user_id = u.id
                          WHERE u.id = ? LIMIT 1");
    
    $decoded = base64_decode($token);
    $parts = explode(':', $decoded);
    $userId = intval($parts[0] ?? 0);
    
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $db->close();
    return $result;
}
