<?php
require_once 'config.php';

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'buat':   buatPembayaran();   break;
    case 'bayar':  prosesBayar();      break;
    case 'detail': detailPembayaran(); break;
    case 'list':   listPembayaran();   break;
    default: respond(false, 'Action tidak valid');
}

function buatPembayaran() {
    requireMethod('POST');
    $user = getAuth();
    if (!$user || $user['role'] !== 'admin') respond(false, 'Unauthorized');

    $body = getBody();
    $pendaftaran_id    = intval($body['pendaftaran_id'] ?? 0);
    $biaya_konsultasi  = floatval($body['biaya_konsultasi'] ?? 150000);
    $biaya_obat        = floatval($body['biaya_obat'] ?? 0);
    $biaya_admin       = floatval($body['biaya_admin'] ?? 25000);
    $jenis_pembayaran  = $body['jenis_pembayaran'] ?? 'tunai';

    if (!$pendaftaran_id) respond(false, 'Pendaftaran ID wajib diisi');

    $db = getDB();

    $cek = $db->prepare("SELECT id FROM pembayaran WHERE pendaftaran_id = ?");
    $cek->bind_param("i", $pendaftaran_id);
    $cek->execute();
    if ($cek->get_result()->num_rows > 0) {
        $db->close();
        respond(false, 'Tagihan sudah dibuat untuk pendaftaran ini');
    }

    $no_invoice = 'INV-' . date('Ymd') . '-' . str_pad($pendaftaran_id, 4, '0', STR_PAD_LEFT);
    $total = $biaya_konsultasi + $biaya_obat + $biaya_admin;

    $status = 'belum_bayar';
    if ($jenis_pembayaran === 'bpjs' || $jenis_pembayaran === 'asuransi') {
        $total = 0;
        $status = 'ditanggung';
    }

    $stmt = $db->prepare("INSERT INTO pembayaran (pendaftaran_id, no_invoice, biaya_konsultasi, biaya_obat, biaya_admin, total, jenis_pembayaran, status)
                          VALUES (?,?,?,?,?,?,?,?)");
    $stmt->bind_param("isddddss", $pendaftaran_id, $no_invoice, $biaya_konsultasi, $biaya_obat, $biaya_admin, $total, $jenis_pembayaran, $status);
    $stmt->execute();
    $id = $stmt->insert_id;
    $db->close();

    respond(true, 'Tagihan berhasil dibuat', [
        'id' => $id,
        'no_invoice' => $no_invoice,
        'total' => $total,
        'status' => $status
    ]);
}

function prosesBayar() {
    requireMethod('POST');
    $user = getAuth();
    if (!$user || $user['role'] !== 'admin') respond(false, 'Unauthorized');

    $body = getBody();
    $id = intval($body['id'] ?? 0);

    $db = getDB();
    $tanggal_bayar = date('Y-m-d H:i:s');
    $stmt = $db->prepare("UPDATE pembayaran SET status='sudah_bayar', tanggal_bayar=? WHERE id=?");
    $stmt->bind_param("si", $tanggal_bayar, $id);
    $stmt->execute();
    $db->close();

    respond(true, 'Pembayaran berhasil dikonfirmasi');
}

function detailPembayaran() {
    $user = getAuth();
    if (!$user) respond(false, 'Unauthorized');

    $pendaftaran_id = intval($_GET['pendaftaran_id'] ?? 0);
    $db = getDB();

    $stmt = $db->prepare("
        SELECT py.*, u.nama as nama_pasien, p.no_rm, pd.no_antrian, pd.tanggal
        FROM pembayaran py
        JOIN pendaftaran pd ON py.pendaftaran_id = pd.id
        JOIN pasien p ON pd.pasien_id = p.id
        JOIN users u ON p.user_id = u.id
        WHERE py.pendaftaran_id = ?
    ");
    $stmt->bind_param("i", $pendaftaran_id);
    $stmt->execute();
    $data = $stmt->get_result()->fetch_assoc();
    $db->close();

    respond(true, 'Berhasil', $data);
}

function listPembayaran() {
    $user = getAuth();
    if (!$user || $user['role'] !== 'admin') respond(false, 'Unauthorized');

    $db = getDB();
    $result = $db->query("
        SELECT py.*, u.nama as nama_pasien, pd.no_antrian, pd.tanggal
        FROM pembayaran py
        JOIN pendaftaran pd ON py.pendaftaran_id = pd.id
        JOIN pasien p ON pd.pasien_id = p.id
        JOIN users u ON p.user_id = u.id
        ORDER BY py.created_at DESC
        LIMIT 50
    ");
    $data = $result->fetch_all(MYSQLI_ASSOC);
    $db->close();
    respond(true, 'Berhasil', $data);
}
