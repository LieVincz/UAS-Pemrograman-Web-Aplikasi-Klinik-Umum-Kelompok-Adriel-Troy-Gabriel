<?php
require_once 'config.php';

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'simpan':        simpanPemeriksaan(); break;
    case 'update':        updatePemeriksaan(); break;
    case 'get':           getPemeriksaan();    break;
    case 'tambah_resep':  tambahResep();       break;
    case 'hapus_resep':   hapusResep();        break;
    default: respond(false, 'Action tidak valid');
}


function simpanPemeriksaan() {
    requireMethod('POST');
    $user = getAuth();
    if (!$user || $user['role'] !== 'dokter') respond(false, 'Unauthorized');

    $body           = getBody();
    $pendaftaran_id = intval($body['pendaftaran_id'] ?? 0);
    $tekanan_darah  = $body['tekanan_darah'] ?? '';
    $suhu           = floatval($body['suhu'] ?? 0);
    $berat_badan    = floatval($body['berat_badan'] ?? 0);
    $tinggi_badan   = floatval($body['tinggi_badan'] ?? 0);
    $diagnosa       = $body['diagnosa'] ?? '';
    $catatan        = $body['catatan'] ?? '';

    if (!$pendaftaran_id || empty($diagnosa)) {
        respond(false, 'Pendaftaran dan diagnosa wajib diisi');
    }

    $db        = getDB();
    $dokter_id = $user['dokter_id'];

    $cek = $db->prepare("SELECT id FROM pemeriksaan WHERE pendaftaran_id = ?");
    $cek->bind_param("i", $pendaftaran_id);
    $cek->execute();
    $existing = $cek->get_result()->fetch_assoc();

    if ($existing) {

        $stmt = $db->prepare(
            "UPDATE pemeriksaan
             SET tekanan_darah=?, suhu=?, berat_badan=?, tinggi_badan=?, diagnosa=?, catatan=?, status='selesai'
             WHERE pendaftaran_id=?"
        );
        $stmt->bind_param("sdddssi",
            $tekanan_darah, $suhu, $berat_badan, $tinggi_badan, $diagnosa, $catatan, $pendaftaran_id
        );
        $stmt->execute();
        $pemeriksaan_id = $existing['id'];
    } else {

        $stmt = $db->prepare(
            "INSERT INTO pemeriksaan
             (pendaftaran_id, dokter_id, tekanan_darah, suhu, berat_badan, tinggi_badan, diagnosa, catatan, status)
             VALUES (?,?,?,?,?,?,?,?,'selesai')"
        );
        $stmt->bind_param("iisdddss",
            $pendaftaran_id, $dokter_id, $tekanan_darah, $suhu, $berat_badan, $tinggi_badan, $diagnosa, $catatan
        );
        $stmt->execute();
        $pemeriksaan_id = $stmt->insert_id;
    }


    $upd = $db->prepare("UPDATE pendaftaran SET status='selesai' WHERE id=?");
    $upd->bind_param("i", $pendaftaran_id);
    $upd->execute();

    $db->close();
    respond(true, 'Pemeriksaan berhasil disimpan', ['pemeriksaan_id' => $pemeriksaan_id]);
}


function updatePemeriksaan() {
    requireMethod('POST');
    $user = getAuth();
    if (!$user || $user['role'] !== 'dokter') respond(false, 'Unauthorized');

    $body          = getBody();
    $id            = intval($body['id'] ?? 0);
    $tekanan_darah = $body['tekanan_darah'] ?? '';
    $suhu          = floatval($body['suhu'] ?? 0);
    $berat_badan   = floatval($body['berat_badan'] ?? 0);
    $tinggi_badan  = floatval($body['tinggi_badan'] ?? 0);
    $diagnosa      = $body['diagnosa'] ?? '';
    $catatan       = $body['catatan'] ?? '';

    $db   = getDB();
    $stmt = $db->prepare(
        "UPDATE pemeriksaan
         SET tekanan_darah=?, suhu=?, berat_badan=?, tinggi_badan=?, diagnosa=?, catatan=?
         WHERE id=?"
    );
    $stmt->bind_param("sdddssi",
        $tekanan_darah, $suhu, $berat_badan, $tinggi_badan, $diagnosa, $catatan, $id
    );
    $stmt->execute();
    $db->close();

    respond(true, 'Pemeriksaan berhasil diupdate');
}

function getPemeriksaan() {
    $user = getAuth();
    if (!$user) respond(false, 'Unauthorized');

    $pendaftaran_id = intval($_GET['pendaftaran_id'] ?? 0);
    $db             = getDB();

    $stmt = $db->prepare(
        "SELECT pm.*, GROUP_CONCAT(r.nama_obat ORDER BY r.id SEPARATOR ', ') as daftar_obat
         FROM pemeriksaan pm
         LEFT JOIN resep r ON r.pemeriksaan_id = pm.id
         WHERE pm.pendaftaran_id = ?
         GROUP BY pm.id"
    );
    $stmt->bind_param("i", $pendaftaran_id);
    $stmt->execute();
    $data = $stmt->get_result()->fetch_assoc();

    if ($data) {
        $r = $db->prepare("SELECT * FROM resep WHERE pemeriksaan_id = ?");
        $r->bind_param("i", $data['id']);
        $r->execute();
        $data['resep'] = $r->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    $db->close();
    respond(true, 'Berhasil', $data);
}


function tambahResep() {
    requireMethod('POST');
    $user = getAuth();
    if (!$user || $user['role'] !== 'dokter') respond(false, 'Unauthorized');

    $body           = getBody();
    $pemeriksaan_id = intval($body['pemeriksaan_id'] ?? 0);
    $nama_obat      = trim($body['nama_obat'] ?? '');
    $dosis          = $body['dosis'] ?? '';
    $aturan_pakai   = $body['aturan_pakai'] ?? '';
    $jumlah         = intval($body['jumlah'] ?? 1);
    $keterangan     = $body['keterangan'] ?? '';

    if (!$pemeriksaan_id || empty($nama_obat)) {
        respond(false, 'Data resep tidak lengkap');
    }

    $db   = getDB();
    $stmt = $db->prepare(
        "INSERT INTO resep (pemeriksaan_id, nama_obat, dosis, aturan_pakai, jumlah, keterangan)
         VALUES (?,?,?,?,?,?)"
    );
    $stmt->bind_param("isssis",
        $pemeriksaan_id, $nama_obat, $dosis, $aturan_pakai, $jumlah, $keterangan
    );
    $stmt->execute();
    $db->close();

    respond(true, 'Resep berhasil ditambahkan');
}

function hapusResep() {
    requireMethod('POST');
    $user = getAuth();
    if (!$user || $user['role'] !== 'dokter') respond(false, 'Unauthorized');

    $body = getBody();
    $id   = intval($body['id'] ?? 0);

    $db   = getDB();
    $stmt = $db->prepare("DELETE FROM resep WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $db->close();

    respond(true, 'Resep berhasil dihapus');
}
