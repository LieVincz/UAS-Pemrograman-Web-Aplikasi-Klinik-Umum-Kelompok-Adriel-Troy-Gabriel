<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'list':    getPendaftaran();   break;
    case 'detail':  getDetail();        break;
    case 'daftar':  daftarAntrian();    break;
    case 'update':  updateStatus();     break;
    case 'delete':  deletePendaftaran();break;
    case 'dokter':  getDokterList();    break;
    default: respond(false, 'Action tidak valid');
}


function getPendaftaran() {
    $user = getAuth();
    if (!$user) respond(false, 'Unauthorized');

    $db = getDB();
    $tanggal = $_GET['tanggal'] ?? date('Y-m-d');

    if ($user['role'] === 'pasien') {
        $stmt = $db->prepare("
            SELECT pd.*, u_d.nama as nama_dokter, d.spesialisasi
            FROM pendaftaran pd
            JOIN pasien p ON pd.pasien_id = p.id
            JOIN dokter d ON pd.dokter_id = d.id
            JOIN users u_d ON d.user_id = u_d.id
            WHERE p.user_id = ?
            ORDER BY pd.created_at DESC
        ");
        $stmt->bind_param("i", $user['id']);
    } elseif ($user['role'] === 'dokter') {
        $stmt = $db->prepare("
            SELECT pd.*, u_p.nama as nama_pasien, p.no_rm
            FROM pendaftaran pd
            JOIN pasien p ON pd.pasien_id = p.id
            JOIN users u_p ON p.user_id = u_p.id
            WHERE pd.dokter_id = ? AND pd.tanggal = ?
            ORDER BY pd.no_antrian ASC
        ");
        $stmt->bind_param("is", $user['dokter_id'], $tanggal);
    } else {
        /
        $stmt = $db->prepare("
            SELECT pd.*, u_p.nama as nama_pasien, p.no_rm,
                   u_d.nama as nama_dokter, d.spesialisasi
            FROM pendaftaran pd
            JOIN pasien p ON pd.pasien_id = p.id
            JOIN users u_p ON p.user_id = u_p.id
            JOIN dokter d ON pd.dokter_id = d.id
            JOIN users u_d ON d.user_id = u_d.id
            WHERE pd.tanggal = ?
            ORDER BY pd.no_antrian ASC
        ");
        $stmt->bind_param("s", $tanggal);
    }

    $stmt->execute();
    $data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $db->close();
    respond(true, 'Berhasil', $data);
}


function getDetail() {
    $user = getAuth();
    if (!$user) respond(false, 'Unauthorized');

    $id = intval($_GET['pendaftaran_id'] ?? $_GET['id'] ?? 0);
    if (!$id) respond(false, 'ID tidak valid');

    $db = getDB();

    $stmt = $db->prepare("
        SELECT
            pd.id                       AS id,
            pd.no_antrian               AS no_antrian,
            pd.pasien_id                AS pasien_id,
            pd.dokter_id                AS dokter_id,
            pd.tanggal                  AS tanggal,
            pd.keluhan                  AS keluhan,
            pd.status                   AS status,
            pd.jenis_pembayaran         AS jenis_pembayaran,
            pd.no_bpjs                  AS no_bpjs,
            pd.no_asuransi              AS no_asuransi,
            pd.untuk_diri_sendiri       AS untuk_diri_sendiri,
            pd.nama_pasien_lain         AS nama_pasien_lain,
            pd.hubungan                 AS hubungan,
            pd.no_hp_pasien_lain        AS no_hp_pasien_lain,
            pd.created_at               AS created_at,

            u_p.nama                    AS nama_pasien,
            p.no_rm                     AS no_rm,
            p.tanggal_lahir             AS tanggal_lahir,
            p.jenis_kelamin             AS jenis_kelamin,
            p.alergi                    AS alergi,

            u_d.nama                    AS nama_dokter,
            d.spesialisasi              AS spesialisasi,

            pm.id                       AS pemeriksaan_id,
            pm.tekanan_darah            AS tekanan_darah,
            pm.suhu                     AS suhu,
            pm.berat_badan              AS berat_badan,
            pm.tinggi_badan             AS tinggi_badan,
            pm.diagnosa                 AS diagnosa,
            pm.catatan                  AS catatan,
            pm.status                   AS status_periksa,

            py.id                       AS pembayaran_id,
            py.no_invoice               AS no_invoice,
            py.total                    AS total,
            py.status                   AS status_bayar,
            py.biaya_konsultasi         AS biaya_konsultasi,
            py.biaya_obat               AS biaya_obat,
            py.biaya_admin              AS biaya_admin,
            py.jenis_pembayaran         AS jenis_bayar

        FROM pendaftaran pd
        JOIN  pasien  p   ON pd.pasien_id  = p.id
        JOIN  users   u_p ON p.user_id     = u_p.id
        JOIN  dokter  d   ON pd.dokter_id  = d.id
        JOIN  users   u_d ON d.user_id     = u_d.id
        LEFT JOIN pemeriksaan pm ON pm.pendaftaran_id = pd.id
        LEFT JOIN pembayaran  py ON py.pendaftaran_id = pd.id
        WHERE pd.id = ?
    ");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $data = $stmt->get_result()->fetch_assoc();

    if (!$data) {
        $db->close();
        respond(false, 'Data tidak ditemukan');
    }


    if (!empty($data['pemeriksaan_id'])) {
        $r = $db->prepare("SELECT * FROM resep WHERE pemeriksaan_id = ?");
        $r->bind_param("i", $data['pemeriksaan_id']);
        $r->execute();
        $data['resep'] = $r->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    $db->close();
    respond(true, 'Berhasil', $data);
}


function daftarAntrian() {
    requireMethod('POST');
    $user = getAuth();
    if (!$user || $user['role'] !== 'pasien') respond(false, 'Unauthorized');

    $body = getBody();
    $dokter_id           = intval($body['dokter_id'] ?? 0);
    $keluhan             = trim($body['keluhan'] ?? '');
    $jenis_pembayaran    = $body['jenis_pembayaran'] ?? 'umum';
    $no_bpjs             = $body['no_bpjs'] ?? '';
    $no_asuransi         = $body['no_asuransi'] ?? '';
    $untuk_diri_sendiri  = intval($body['untuk_diri_sendiri'] ?? 1);
    $nama_pasien_lain    = trim($body['nama_pasien_lain'] ?? '');
    $hubungan            = trim($body['hubungan'] ?? '');
    $no_hp_pasien_lain   = trim($body['no_hp_pasien_lain'] ?? '');

    if (!$dokter_id || empty($keluhan)) {
        respond(false, 'Dokter dan keluhan wajib diisi');
    }
    if (!$untuk_diri_sendiri && empty($nama_pasien_lain)) {
        respond(false, 'Nama pasien wajib diisi jika mendaftar untuk orang lain');
    }

    $db = getDB();
    $tanggal = date('Y-m-d');

    $count = $db->query("SELECT COUNT(*) as c FROM pendaftaran WHERE tanggal = '$tanggal'")->fetch_assoc()['c'];
    $no_antrian = 'A' . str_pad($count + 1, 3, '0', STR_PAD_LEFT);

    $pasien_id = $user['pasien_id'];
    $stmt = $db->prepare("INSERT INTO pendaftaran
        (no_antrian, pasien_id, dokter_id, tanggal, keluhan, jenis_pembayaran,
         no_bpjs, no_asuransi, untuk_diri_sendiri, nama_pasien_lain, hubungan, no_hp_pasien_lain)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");

    $stmt->bind_param("siisssssisss",
        $no_antrian, $pasien_id, $dokter_id, $tanggal, $keluhan,
        $jenis_pembayaran, $no_bpjs, $no_asuransi,
        $untuk_diri_sendiri, $nama_pasien_lain, $hubungan, $no_hp_pasien_lain
    );
    $stmt->execute();
    $id = $stmt->insert_id;
    $db->close();

    $nama_display = $untuk_diri_sendiri ? $user['nama'] : $nama_pasien_lain;
    respond(true, "Berhasil daftar untuk $nama_display! Nomor antrian: $no_antrian", [
        'id'          => $id,
        'no_antrian'  => $no_antrian,
        'tanggal'     => $tanggal,
        'nama_pasien' => $nama_display
    ]);
}


function updateStatus() {
    requireMethod('POST');
    $user = getAuth();
    if (!$user || $user['role'] === 'pasien') respond(false, 'Unauthorized');

    $body   = getBody();
    $id     = intval($body['id'] ?? 0);
    $status = $body['status'] ?? '';

    $allowed = ['menunggu', 'dipanggil', 'selesai', 'batal'];
    if (!in_array($status, $allowed)) respond(false, 'Status tidak valid');

    $db = getDB();
    $stmt = $db->prepare("UPDATE pendaftaran SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $id);
    $stmt->execute();
    $db->close();

    respond(true, 'Status berhasil diupdate');
}


function deletePendaftaran() {
    requireMethod('POST');
    $user = getAuth();
    if (!$user || $user['role'] !== 'admin') respond(false, 'Unauthorized');

    $body = getBody();
    $id = intval($body['id'] ?? 0);

    $db = getDB();
    $stmt = $db->prepare("UPDATE pendaftaran SET status = 'batal' WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $db->close();

    respond(true, 'Pendaftaran dibatalkan');
}


function getDokterList() {
    $db = getDB();
    $result = $db->query("SELECT d.id, u.nama, d.spesialisasi, d.jadwal FROM dokter d JOIN users u ON d.user_id = u.id");
    $data = $result->fetch_all(MYSQLI_ASSOC);
    $db->close();
    respond(true, 'Berhasil', $data);
}
