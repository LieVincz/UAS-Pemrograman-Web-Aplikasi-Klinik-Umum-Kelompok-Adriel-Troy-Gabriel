<?php

require_once 'config.php';

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'riwayat':    getRiwayat();    break;
    case 'dashboard':  getDashboard();  break;
    case 'profil':     getProfil();     break;
    case 'edit_profil':editProfil();    break;
    default: respond(false, 'Action tidak valid');
}

function getRiwayat() {
    $user = getAuth();
    if (!$user) respond(false, 'Unauthorized');

    $db = getDB();

    if ($user['role'] === 'pasien') {
        $stmt = $db->prepare("
            SELECT pd.id as pendaftaran_id, pd.no_antrian, pd.tanggal, pd.keluhan, pd.status,
                   u_d.nama as nama_dokter, d.spesialisasi,
                   pm.diagnosa, pm.catatan, pm.tekanan_darah, pm.suhu, pm.berat_badan, pm.tinggi_badan,
                   py.total, py.status as status_bayar, py.no_invoice
            FROM pendaftaran pd
            JOIN pasien p ON pd.pasien_id = p.id
            JOIN dokter d ON pd.dokter_id = d.id
            JOIN users u_d ON d.user_id = u_d.id
            LEFT JOIN pemeriksaan pm ON pm.pendaftaran_id = pd.id
            LEFT JOIN pembayaran py ON py.pendaftaran_id = pd.id
            WHERE p.user_id = ?
            ORDER BY pd.tanggal DESC, pd.created_at DESC
        ");
        $stmt->bind_param("i", $user['id']);
    } else {
        
        $pasien_id = intval($_GET['pasien_id'] ?? 0);
        $stmt = $db->prepare("
            SELECT pd.id as pendaftaran_id, pd.no_antrian, pd.tanggal, pd.keluhan, pd.status,
                   u_d.nama as nama_dokter, d.spesialisasi,
                   pm.diagnosa, pm.catatan, pm.tekanan_darah, pm.suhu, pm.berat_badan, pm.tinggi_badan,
                   py.total, py.status as status_bayar
            FROM pendaftaran pd
            JOIN dokter d ON pd.dokter_id = d.id
            JOIN users u_d ON d.user_id = u_d.id
            LEFT JOIN pemeriksaan pm ON pm.pendaftaran_id = pd.id
            LEFT JOIN pembayaran py ON py.pendaftaran_id = pd.id
            WHERE pd.pasien_id = ?
            ORDER BY pd.tanggal DESC
        ");
        $stmt->bind_param("i", $pasien_id);
    }

    $stmt->execute();
    $data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    
    foreach ($data as &$row) {
        if (!empty($row['pendaftaran_id'])) {
            $r = $db->prepare("SELECT r.* FROM resep r 
                               JOIN pemeriksaan pm ON r.pemeriksaan_id = pm.id 
                               WHERE pm.pendaftaran_id = ?");
            $r->bind_param("i", $row['pendaftaran_id']);
            $r->execute();
            $row['resep'] = $r->get_result()->fetch_all(MYSQLI_ASSOC);
        }
    }

    $db->close();
    respond(true, 'Berhasil', $data);
}


function getDashboard() {
    $user = getAuth();
    if (!$user) respond(false, 'Unauthorized');

    $db = getDB();
    $today = date('Y-m-d');

    $stats = [];

    if ($user['role'] === 'admin') {
        $r = $db->query("SELECT COUNT(*) as c FROM pendaftaran WHERE tanggal = '$today'");
        $stats['pasien_hari_ini'] = $r->fetch_assoc()['c'];

        $r = $db->query("SELECT COUNT(*) as c FROM pendaftaran WHERE tanggal = '$today' AND status = 'menunggu'");
        $stats['antrian_menunggu'] = $r->fetch_assoc()['c'];

        $r = $db->query("SELECT IFNULL(SUM(total),0) as total FROM pembayaran WHERE DATE(created_at) = '$today' AND status = 'sudah_bayar'");
        $stats['pendapatan_hari_ini'] = $r->fetch_assoc()['total'];

        $r = $db->query("SELECT COUNT(*) as c FROM pasien");
        $stats['total_pasien'] = $r->fetch_assoc()['c'];

        $r = $db->query("SELECT pd.no_antrian, pd.status, u.nama as nama_pasien, pd.keluhan
                         FROM pendaftaran pd JOIN pasien p ON pd.pasien_id = p.id JOIN users u ON p.user_id = u.id
                         WHERE pd.tanggal = '$today' ORDER BY pd.no_antrian ASC LIMIT 10");
        $stats['antrian_list'] = $r->fetch_all(MYSQLI_ASSOC);

    } elseif ($user['role'] === 'dokter') {
        $dokter_id = $user['dokter_id'];

        $r = $db->prepare("SELECT COUNT(*) as c FROM pendaftaran WHERE tanggal = ? AND dokter_id = ?");
        $r->bind_param("si", $today, $dokter_id);
        $r->execute();
        $stats['pasien_hari_ini'] = $r->get_result()->fetch_assoc()['c'];

        $r = $db->prepare("SELECT COUNT(*) as c FROM pendaftaran WHERE tanggal = ? AND dokter_id = ? AND status = 'menunggu'");
        $r->bind_param("si", $today, $dokter_id);
        $r->execute();
        $stats['antrian_menunggu'] = $r->get_result()->fetch_assoc()['c'];

        $r = $db->prepare("SELECT pd.id, pd.no_antrian, pd.status, u.nama as nama_pasien, pd.keluhan
                           FROM pendaftaran pd JOIN pasien p ON pd.pasien_id = p.id JOIN users u ON p.user_id = u.id
                           WHERE pd.tanggal = ? AND pd.dokter_id = ?
                           ORDER BY pd.no_antrian ASC");
        $r->bind_param("si", $today, $dokter_id);
        $r->execute();
        $stats['antrian_list'] = $r->get_result()->fetch_all(MYSQLI_ASSOC);

    } elseif ($user['role'] === 'pasien') {
        $pasien_id = $user['pasien_id'];

        $r = $db->prepare("SELECT COUNT(*) as c FROM pendaftaran WHERE pasien_id = ?");
        $r->bind_param("i", $pasien_id);
        $r->execute();
        $stats['total_kunjungan'] = $r->get_result()->fetch_assoc()['c'];

        $r = $db->prepare("SELECT pd.*, u_d.nama as nama_dokter FROM pendaftaran pd
                           JOIN dokter d ON pd.dokter_id = d.id JOIN users u_d ON d.user_id = u_d.id
                           WHERE pd.pasien_id = ? AND pd.tanggal = ? AND pd.status IN ('menunggu','dipanggil')
                           LIMIT 1");
        $r->bind_param("is", $pasien_id, $today);
        $r->execute();
        $stats['antrian_aktif'] = $r->get_result()->fetch_assoc();

        $r = $db->prepare("SELECT py.* FROM pembayaran py JOIN pendaftaran pd ON py.pendaftaran_id = pd.id
                           WHERE pd.pasien_id = ? AND py.status = 'belum_bayar' LIMIT 1");
        $r->bind_param("i", $pasien_id);
        $r->execute();
        $stats['tagihan_pending'] = $r->get_result()->fetch_assoc();
    }

    $db->close();
    respond(true, 'Berhasil', $stats);
}


function getProfil() {
    $user = getAuth();
    if (!$user) respond(false, 'Unauthorized');
    unset($user['password']);
    respond(true, 'Berhasil', $user);
}


function editProfil() {
    requireMethod('POST');
    $user = getAuth();
    if (!$user) respond(false, 'Unauthorized');

    $body = getBody();
    $nama       = trim($body['nama'] ?? $user['nama']);
    $no_telepon = trim($body['no_telepon'] ?? '');
    $alamat     = trim($body['alamat'] ?? '');

    $db = getDB();
    $stmt = $db->prepare("UPDATE users SET nama=?, no_telepon=?, alamat=? WHERE id=?");
    $stmt->bind_param("sssi", $nama, $no_telepon, $alamat, $user['id']);
    $stmt->execute();


    if ($user['role'] === 'pasien') {
        $alergi = $body['alergi'] ?? '';
        $tl     = $body['tanggal_lahir'] ?? '';
        $jk     = $body['jenis_kelamin'] ?? '';
        $gol    = $body['golongan_darah'] ?? '';
        $s = $db->prepare("UPDATE pasien SET alergi=?, tanggal_lahir=?, jenis_kelamin=?, golongan_darah=? WHERE user_id=?");
        $s->bind_param("ssssi", $alergi, $tl, $jk, $gol, $user['id']);
        $s->execute();
    }

    $db->close();
    respond(true, 'Profil berhasil diupdate');
}
