-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2026 at 12:30 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `klinik_umum`
--

-- --------------------------------------------------------

--
-- Table structure for table `dokter`
--

CREATE TABLE `dokter` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `spesialisasi` varchar(100) DEFAULT 'Umum',
  `no_str` varchar(50) DEFAULT NULL,
  `jadwal` text DEFAULT NULL COMMENT 'JSON format jadwal praktik',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dokter`
--

INSERT INTO `dokter` (`id`, `user_id`, `spesialisasi`, `no_str`, `jadwal`, `created_at`) VALUES
(1, 2, 'Umum', 'STR-001-2024', '{\"senin\":\"08:00-12:00\",\"selasa\":\"08:00-12:00\",\"rabu\":\"13:00-17:00\",\"kamis\":\"08:00-12:00\",\"jumat\":\"08:00-11:00\"}', '2026-06-07 07:37:23');

-- --------------------------------------------------------

--
-- Table structure for table `pasien`
--

CREATE TABLE `pasien` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `no_rm` varchar(20) NOT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `jenis_kelamin` enum('L','P') DEFAULT NULL,
  `golongan_darah` enum('A','B','AB','O','') DEFAULT NULL,
  `alergi` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pasien`
--

INSERT INTO `pasien` (`id`, `user_id`, `no_rm`, `tanggal_lahir`, `jenis_kelamin`, `golongan_darah`, `alergi`, `created_at`) VALUES
(1, 3, 'RM-000001', '1995-05-15', 'L', 'O', NULL, '2026-06-07 07:37:23'),
(2, 4, 'RM-000002', '0000-00-00', '', '', '', '2026-06-07 08:58:57');

-- --------------------------------------------------------

--
-- Table structure for table `pemeriksaan`
--

CREATE TABLE `pemeriksaan` (
  `id` int(11) NOT NULL,
  `pendaftaran_id` int(11) NOT NULL,
  `dokter_id` int(11) NOT NULL,
  `tanggal_periksa` datetime DEFAULT current_timestamp(),
  `tekanan_darah` varchar(20) DEFAULT NULL,
  `suhu` decimal(4,1) DEFAULT NULL,
  `berat_badan` decimal(5,2) DEFAULT NULL,
  `tinggi_badan` decimal(5,2) DEFAULT NULL,
  `diagnosa` text DEFAULT NULL,
  `catatan` text DEFAULT NULL,
  `status` enum('proses','selesai') DEFAULT 'proses',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pemeriksaan`
--

INSERT INTO `pemeriksaan` (`id`, `pendaftaran_id`, `dokter_id`, `tanggal_periksa`, `tekanan_darah`, `suhu`, `berat_badan`, `tinggi_badan`, `diagnosa`, `catatan`, `status`, `created_at`) VALUES
(1, 35, 1, '2026-06-08 17:10:13', '120', 36.0, 58.00, 128.00, 'kurang makan nasi', '', 'selesai', '2026-06-08 10:10:13'),
(2, 36, 1, '2026-06-08 17:30:10', '120/70', 36.7, 78.00, 173.00, 'Peradangan Tenggorokan', 'Perbanyak minum air putih dan kurangi makanan berminyak', 'selesai', '2026-06-08 10:30:10'),
(3, 37, 1, '2026-06-08 21:49:12', '120/80', 37.0, 67.00, 176.00, 'Kurang asupan vitamin  dan serat', '', 'selesai', '2026-06-08 14:49:12'),
(4, 38, 1, '2026-06-08 21:56:32', '130/90', 36.6, 57.00, 160.00, 'Batuk berdahak', 'Kurangi makanan berminyak dan Minuman dingin', 'selesai', '2026-06-08 14:56:32'),
(5, 47, 1, '2026-06-09 01:33:47', '120/80', 36.0, 56.00, 160.00, 'Batuk berdahak', 'KLurangi makanan berminyak', 'selesai', '2026-06-08 18:33:47'),
(6, 1, 1, '2026-06-09 01:55:28', '120/80', 37.8, 65.00, 170.00, 'ISPA (Infeksi Saluran Pernapasan Atas)', 'Istirahat yang cukup, minum banyak air putih', 'selesai', '2026-06-08 18:55:28'),
(7, 50, 1, '2026-06-09 05:16:26', '120/90', 36.0, 75.00, 167.00, 'Batuk berdahak', 'Kurangi makanan berminyak', 'selesai', '2026-06-08 22:16:26');

-- --------------------------------------------------------

--
-- Table structure for table `pendaftaran`
--

CREATE TABLE `pendaftaran` (
  `id` int(11) NOT NULL,
  `no_antrian` varchar(20) NOT NULL,
  `pasien_id` int(11) NOT NULL,
  `dokter_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `keluhan` text NOT NULL,
  `status` enum('menunggu','dipanggil','selesai','batal') DEFAULT 'menunggu',
  `jenis_pembayaran` enum('umum','bpjs','asuransi') DEFAULT 'umum',
  `no_bpjs` varchar(20) DEFAULT NULL,
  `no_asuransi` varchar(20) DEFAULT NULL,
  `untuk_diri_sendiri` tinyint(1) DEFAULT 1,
  `nama_pasien_lain` varchar(100) DEFAULT NULL,
  `hubungan` varchar(50) DEFAULT NULL,
  `no_hp_pasien_lain` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `waktu_daftar` datetime DEFAULT NULL,
  `waktu_berlaku` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pendaftaran`
--

INSERT INTO `pendaftaran` (`id`, `no_antrian`, `pasien_id`, `dokter_id`, `tanggal`, `keluhan`, `status`, `jenis_pembayaran`, `no_bpjs`, `no_asuransi`, `untuk_diri_sendiri`, `nama_pasien_lain`, `hubungan`, `no_hp_pasien_lain`, `created_at`, `waktu_daftar`, `waktu_berlaku`, `updated_at`) VALUES
(1, 'A001', 2, 1, '2026-06-07', 'gangguan pola pikir', 'dipanggil', 'bpjs', '58782588', '', 0, 'abil', 'Lainnya', '05586322466', '2026-06-07 09:21:06', NULL, NULL, '2026-06-07 10:14:03'),
(2, 'A002', 2, 1, '2026-06-07', 'gangguan pemikiran', 'batal', 'bpjs', '54470096', '', 0, 'abil', 'Kakek/Nenek', '4355435453', '2026-06-07 09:21:59', NULL, NULL, '2026-06-07 10:14:13'),
(3, 'A003', 2, 1, '2026-06-07', 'gangguan pikiran', 'dipanggil', 'bpjs', '9087987986', '', 0, 'abil', 'Kakek/Nenek', '055489649', '2026-06-07 09:27:37', NULL, NULL, '2026-06-07 10:14:09'),
(4, 'A004', 2, 1, '2026-06-07', 'fhijh', 'batal', 'umum', '', '', 1, '', '', '', '2026-06-07 09:29:55', NULL, NULL, '2026-06-07 10:54:41'),
(35, 'A001', 2, 1, '2026-06-08', 'susah makan', 'selesai', 'asuransi', '', '3424234', 1, '', '', '', '2026-06-08 07:44:40', NULL, NULL, '2026-06-08 10:10:13'),
(36, 'A002', 2, 1, '2026-06-08', 'susah tidur', 'selesai', 'bpjs', '3242343242', '', 0, 'Melody', 'Lainnya', '085565486', '2026-06-08 08:29:19', NULL, NULL, '2026-06-08 10:30:10'),
(37, 'A003', 2, 1, '2026-06-08', 'haiihai', 'selesai', 'umum', '', '', 1, '', '', '', '2026-06-08 08:33:40', NULL, NULL, '2026-06-08 14:49:12'),
(38, 'A004', 2, 1, '2026-06-08', 'VD', 'selesai', 'umum', '', '', 1, '', '', '', '2026-06-08 08:38:29', NULL, NULL, '2026-06-08 14:56:32'),
(43, 'A005', 2, 1, '2026-06-08', 'test', 'batal', 'umum', '', '', 1, '', '', '', '2026-06-08 09:55:23', '2026-06-08 11:55:23', '2026-06-08 12:55:23', '2026-06-08 16:21:10'),
(44, 'A006', 2, 1, '2026-06-08', 'Sakit saat menelan dan tenggorokan gatal', 'dipanggil', 'bpjs', '123232', '', 1, '', '', '', '2026-06-08 16:28:00', '2026-06-08 18:28:00', '2026-06-08 19:28:00', '2026-06-08 16:30:29'),
(45, 'A007', 2, 1, '2026-06-08', 'Bersin terus menerus', 'menunggu', 'bpjs', '2488', '', 1, '', '', '', '2026-06-08 16:43:18', '2026-06-08 18:43:18', '2026-06-08 19:43:18', '2026-06-08 16:43:18'),
(46, 'A008', 2, 1, '2026-06-08', 'lemas', 'menunggu', 'umum', '', '', 1, '', '', '', '2026-06-08 18:08:57', NULL, NULL, '2026-06-08 18:08:57'),
(47, 'A001', 2, 1, '2026-06-09', 'test', 'dipanggil', 'umum', '', '', 1, '', '', '', '2026-06-08 18:31:04', NULL, NULL, '2026-06-08 21:45:37'),
(49, 'A002', 2, 1, '2026-06-09', 'test', 'batal', 'umum', '', '', 1, '', '', '', '2026-06-08 22:07:21', NULL, NULL, '2026-06-08 22:12:20'),
(50, 'A003', 2, 1, '2026-06-09', 'Batuk terus menerus', 'selesai', 'bpjs', '768786', '', 0, 'Rudi', 'Kakek/Nenek', '0856967', '2026-06-08 22:09:13', NULL, NULL, '2026-06-08 22:16:26'),
(51, 'A004', 2, 1, '2026-06-09', 'test', 'batal', 'umum', '', '', 1, '', '', '', '2026-06-08 22:10:15', NULL, NULL, '2026-06-08 22:12:33');

-- --------------------------------------------------------

--
-- Table structure for table `resep`
--

CREATE TABLE `resep` (
  `id` int(11) NOT NULL,
  `pemeriksaan_id` int(11) NOT NULL,
  `nama_obat` varchar(100) NOT NULL,
  `dosis` varchar(50) DEFAULT NULL,
  `aturan_pakai` varchar(100) DEFAULT NULL,
  `jumlah` int(11) DEFAULT 1,
  `keterangan` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `resep`
--

INSERT INTO `resep` (`id`, `pemeriksaan_id`, `nama_obat`, `dosis`, `aturan_pakai`, `jumlah`, `keterangan`, `created_at`) VALUES
(1, 4, 'tghtf', 'g', '5hgfh', 54, 'hgffgh', '2026-06-08 15:47:10'),
(2, 5, 'KOMIK OBH', '1', '3 kali sehari setelah makan', 1, '', '2026-06-08 18:33:51'),
(3, 7, 'KOMIK OBH', '1', '3 kali setelah makan', 1, '', '2026-06-08 22:16:27');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','dokter','pasien') NOT NULL DEFAULT 'pasien',
  `no_telepon` varchar(20) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nama`, `email`, `password`, `role`, `no_telepon`, `alamat`, `foto`, `created_at`, `updated_at`) VALUES
(1, 'Admin Klinik', 'admin@klinik.com', 'e10adc3949ba59abbe56e057f20f883e', 'admin', NULL, NULL, NULL, '2026-06-07 07:37:23', '2026-06-07 10:13:30'),
(2, 'Dr. Budi Santoso', 'dokter@klinik.com', 'e10adc3949ba59abbe56e057f20f883e', 'dokter', NULL, NULL, NULL, '2026-06-07 07:37:23', '2026-06-07 10:41:26'),
(3, 'Pasien Demo', 'pasien@klinik.com', '43b39eea8ff4885aa49ec46c39a08178', 'pasien', NULL, NULL, NULL, '2026-06-07 07:37:23', '2026-06-07 07:37:23'),
(4, 'Adriel Lie', 'ad@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'pasien', '08596322654', 'gutu', NULL, '2026-06-07 08:58:57', '2026-06-07 09:04:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dokter`
--
ALTER TABLE `dokter`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `pasien`
--
ALTER TABLE `pasien`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `no_rm` (`no_rm`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `pemeriksaan`
--
ALTER TABLE `pemeriksaan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pendaftaran_id` (`pendaftaran_id`),
  ADD KEY `dokter_id` (`dokter_id`);

--
-- Indexes for table `pendaftaran`
--
ALTER TABLE `pendaftaran`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_antrian_tanggal` (`no_antrian`,`tanggal`),
  ADD KEY `pasien_id` (`pasien_id`),
  ADD KEY `dokter_id` (`dokter_id`);

--
-- Indexes for table `resep`
--
ALTER TABLE `resep`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pemeriksaan_id` (`pemeriksaan_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dokter`
--
ALTER TABLE `dokter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pasien`
--
ALTER TABLE `pasien`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pemeriksaan`
--
ALTER TABLE `pemeriksaan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pendaftaran`
--
ALTER TABLE `pendaftaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `resep`
--
ALTER TABLE `resep`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dokter`
--
ALTER TABLE `dokter`
  ADD CONSTRAINT `dokter_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `pasien`
--
ALTER TABLE `pasien`
  ADD CONSTRAINT `pasien_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `pemeriksaan`
--
ALTER TABLE `pemeriksaan`
  ADD CONSTRAINT `pemeriksaan_ibfk_1` FOREIGN KEY (`pendaftaran_id`) REFERENCES `pendaftaran` (`id`),
  ADD CONSTRAINT `pemeriksaan_ibfk_2` FOREIGN KEY (`dokter_id`) REFERENCES `dokter` (`id`);

--
-- Constraints for table `pendaftaran`
--
ALTER TABLE `pendaftaran`
  ADD CONSTRAINT `pendaftaran_ibfk_1` FOREIGN KEY (`pasien_id`) REFERENCES `pasien` (`id`),
  ADD CONSTRAINT `pendaftaran_ibfk_2` FOREIGN KEY (`dokter_id`) REFERENCES `dokter` (`id`);

--
-- Constraints for table `resep`
--
ALTER TABLE `resep`
  ADD CONSTRAINT `resep_ibfk_1` FOREIGN KEY (`pemeriksaan_id`) REFERENCES `pemeriksaan` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
